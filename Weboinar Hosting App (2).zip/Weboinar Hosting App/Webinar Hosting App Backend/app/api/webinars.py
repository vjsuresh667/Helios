from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ... import crud, schemas
from ...core.database import get_db

router = APIRouter()

@router.post("/", response_model=schemas.Webinar)
def create_webinar(
    webinar: schemas.WebinarCreate,
    db: Session = Depends(get_db)
    # In a real app, you would add a dependency to get the current user:
    # current_user: models.User = Depends(get_current_active_user)
):
    # For this example, we'll hardcode the user_id
    # Replace 1 with current_user.id in your full application
    user_id = 1
    return crud.webinar.create_webinar(db=db, webinar=webinar, user_id=user_id)


@router.get("/", response_model=List[schemas.Webinar])
def read_webinars(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    webinars = crud.webinar.get_webinars(db, skip=skip, limit=limit)
    return webinars
