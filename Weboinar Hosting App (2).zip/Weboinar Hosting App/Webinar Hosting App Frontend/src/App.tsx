import { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { LiveWebinar } from './components/LiveWebinar';
import { WebinarDetails } from './components/WebinarDetails';
import { Navigation } from './components/Navigation';
import { LoginSelection } from './components/auth/LoginSelection';
import { AttendeeLogin } from './components/auth/AttendeeLogin';
import { HostLogin } from './components/auth/HostLogin';
import { HostDashboard } from './components/host/HostDashboard';
import { CreateWebinar } from './components/host/CreateWebinar';
import { EditWebinar } from './components/host/EditWebinar';
import { WebinarReplay } from './components/WebinarReplay';
import { Toaster } from './components/ui/sonner';

export type View = 'dashboard' | 'live' | 'details' | 'profile' | 'create-webinar' | 'edit-webinar' | 'replay';
export type AuthView = 'selection' | 'attendee-login' | 'host-login';
export type UserType = 'attendee' | 'host';
export type WebinarStatus = 'upcoming' | 'live' | 'completed';

export interface Webinar {
  id: string;
  title: string;
  description: string;
  speaker: string;
  speakerTitle: string;
  date: Date;
  duration: string;
  tags: string[];
  thumbnail: string;
  status: WebinarStatus;
  registered?: boolean;
  matchScore?: number;
  recordingUrl?: string;
}

export interface User {
  name: string;
  email: string;
  type: UserType;
  role?: string;
  company?: string;
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authView, setAuthView] = useState<AuthView>('selection');
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [selectedWebinar, setSelectedWebinar] = useState<Webinar | null>(null);
  const [webinars, setWebinars] = useState<Webinar[]>([]);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setAuthView('selection');
    setCurrentView('dashboard');
  };

  const handleViewWebinar = (webinar: Webinar) => {
    setSelectedWebinar(webinar);
    setCurrentView('details');
  };

  const handleJoinLive = (webinar: Webinar) => {
    setSelectedWebinar(webinar);
    setCurrentView('live');
  };

  const handleCreateWebinar = (newWebinar: Omit<Webinar, 'id'>) => {
    const webinar: Webinar = {
      ...newWebinar,
      id: Date.now().toString(),
    };
    setWebinars([...webinars, webinar]);
    setCurrentView('dashboard');
  };

  const handleEditWebinar = (webinar: Webinar) => {
    setSelectedWebinar(webinar);
    setCurrentView('edit-webinar');
  };

  const handleUpdateWebinar = (id: string, updatedWebinar: Omit<Webinar, 'id'>) => {
    setWebinars(prevWebinars => 
      prevWebinars.map(w => w.id === id ? { id, ...updatedWebinar } : w)
    );
    setCurrentView('dashboard');
  };

  const handleDeleteWebinar = (id: string) => {
    setWebinars(webinars.filter(w => w.id !== id));
    setCurrentView('dashboard');
  };

  const handleReplayWebinar = (webinar: Webinar) => {
    setSelectedWebinar(webinar);
    setCurrentView('replay');
  };

  // Show login flow if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="size-full flex flex-col bg-background">
        <Toaster />
        {authView === 'selection' && (
          <LoginSelection onSelectType={setAuthView} />
        )}
        {authView === 'attendee-login' && (
          <AttendeeLogin 
            onLogin={handleLogin}
            onBack={() => setAuthView('selection')}
          />
        )}
        {authView === 'host-login' && (
          <HostLogin 
            onLogin={handleLogin}
            onBack={() => setAuthView('selection')}
          />
        )}
      </div>
    );
  }

  // Show appropriate dashboard based on user type
  return (
    <div className="size-full flex flex-col bg-background">
      <Toaster />
      
      {user?.type === 'host' ? (
        <>
          <Navigation 
            currentView={currentView}
            onNavigate={setCurrentView}
            user={user}
            onLogout={handleLogout}
          />
          <div className="flex-1 overflow-hidden">
            {currentView === 'dashboard' && (
              <HostDashboard 
                user={user}
                onViewWebinar={handleViewWebinar}
                onCreateWebinar={() => setCurrentView('create-webinar')}
                onEditWebinar={handleEditWebinar}
                webinars={webinars}
              />
            )}

            {currentView === 'create-webinar' && (
              <CreateWebinar
                user={user}
                onBack={() => setCurrentView('dashboard')}
                onCreate={handleCreateWebinar}
              />
            )}

            {currentView === 'edit-webinar' && selectedWebinar && (
              <EditWebinar
                user={user}
                webinar={selectedWebinar}
                onBack={() => setCurrentView('dashboard')}
                onUpdate={handleUpdateWebinar}
                onDelete={handleDeleteWebinar}
              />
            )}

            {currentView === 'live' && selectedWebinar && (
              <LiveWebinar 
                webinar={selectedWebinar}
                onBack={() => setCurrentView('dashboard')}
                userType={user.type}
              />
            )}

            {currentView === 'details' && selectedWebinar && (
              <WebinarDetails 
                webinar={selectedWebinar}
                onBack={() => setCurrentView('dashboard')}
                onJoinLive={handleJoinLive}
                onReplay={handleReplayWebinar}
              />
            )}

            {currentView === 'replay' && selectedWebinar && (
              <WebinarReplay 
                webinar={selectedWebinar}
                onBack={() => setCurrentView('dashboard')}
              />
            )}
          </div>
        </>
      ) : (
        <>
          <Navigation 
            currentView={currentView}
            onNavigate={setCurrentView}
            user={user}
            onLogout={handleLogout}
          />

          <div className="flex-1 overflow-hidden">
            {currentView === 'dashboard' && (
              <Dashboard 
                onViewWebinar={handleViewWebinar}
                onJoinLive={handleJoinLive}
                onReplay={handleReplayWebinar}
                user={user}
              />
            )}
            
            {currentView === 'live' && selectedWebinar && (
              <LiveWebinar 
                webinar={selectedWebinar}
                onBack={() => setCurrentView('dashboard')}
                userType={user.type}
              />
            )}

            {currentView === 'details' && selectedWebinar && (
              <WebinarDetails 
                webinar={selectedWebinar}
                onBack={() => setCurrentView('dashboard')}
                onJoinLive={handleJoinLive}
                onReplay={handleReplayWebinar}
              />
            )}

            {currentView === 'replay' && selectedWebinar && (
              <WebinarReplay 
                webinar={selectedWebinar}
                onBack={() => setCurrentView('dashboard')}
              />
            )}
          </div>
        </>
      )}
    </div>
  );
}