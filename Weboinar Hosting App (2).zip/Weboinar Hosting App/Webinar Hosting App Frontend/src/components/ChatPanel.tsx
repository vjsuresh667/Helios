import { useState, useEffect, useRef } from 'react';
import { Send, Bot, AlertCircle, ThumbsUp } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { toast } from 'sonner@2.0.3';

interface Message {
  id: string;
  user: string;
  avatar?: string;
  message: string;
  timestamp: Date;
  flagged?: boolean;
  aiModerated?: boolean;
  isAI?: boolean;
}

interface ChatPanelProps {
  isAIEnabled: boolean;
}

export function ChatPanel({ isAIEnabled }: ChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      user: 'Alex Chen',
      message: 'Great presentation! Looking forward to the Q&A.',
      timestamp: new Date(Date.now() - 300000),
    },
    {
      id: '2',
      user: 'Maria Garcia',
      message: 'Can you explain more about the AI features?',
      timestamp: new Date(Date.now() - 240000),
    },
    {
      id: '3',
      user: 'AI Assistant',
      message: 'I can help answer that! The AI features include automated transcription, smart Q&A matching, and sentiment analysis.',
      timestamp: new Date(Date.now() - 230000),
      isAI: true,
    },
    {
      id: '4',
      user: 'John Smith',
      message: 'This is exactly what we need for our team!',
      timestamp: new Date(Date.now() - 180000),
    },
  ]);
  const [newMessage, setNewMessage] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleSend = () => {
    if (!newMessage.trim()) return;

    const message: Message = {
      id: Date.now().toString(),
      user: 'You',
      message: newMessage,
      timestamp: new Date(),
    };

    // Simple AI moderation simulation
    if (isAIEnabled) {
      const lowerMessage = newMessage.toLowerCase();
      if (lowerMessage.includes('spam') || lowerMessage.includes('inappropriate')) {
        message.flagged = true;
        message.aiModerated = true;
        toast.error('Message flagged by AI moderator for review');
      }
    }

    setMessages([...messages, message]);
    setNewMessage('');

    // Simulate AI auto-response for questions
    if (isAIEnabled && newMessage.includes('?')) {
      setTimeout(() => {
        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          user: 'AI Assistant',
          message: 'That\'s a great question! The speaker will address this in the Q&A section shortly. I\'ve also added it to the priority queue.',
          timestamp: new Date(),
          isAI: true,
        };
        setMessages(prev => [...prev, aiResponse]);
      }, 1500);
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div className="h-full flex flex-col">
      <ScrollArea className="flex-1 p-4">
        <div ref={scrollRef} className="space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.flagged ? 'opacity-50' : ''}`}
            >
              <Avatar className="size-8 shrink-0">
                <AvatarImage src={msg.avatar} />
                <AvatarFallback>
                  {msg.isAI ? <Bot className="size-4" /> : msg.user.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm">{msg.user}</span>
                  {msg.isAI && (
                    <Badge variant="secondary" className="text-xs">
                      AI
                    </Badge>
                  )}
                  {msg.aiModerated && (
                    <Badge variant="destructive" className="text-xs gap-1">
                      <AlertCircle className="size-3" />
                      Flagged
                    </Badge>
                  )}
                  <span className="text-xs text-muted-foreground">
                    {msg.timestamp.toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <p className="text-sm break-words">{msg.message}</p>
                {msg.isAI && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-1 h-6 text-xs gap-1"
                  >
                    <ThumbsUp className="size-3" />
                    Helpful
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      <div className="p-4 border-t border-border">
        {isAIEnabled && (
          <div className="mb-2 text-xs text-muted-foreground flex items-center gap-1">
            <Bot className="size-3" />
            AI moderation active
          </div>
        )}
        <div className="flex gap-2">
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <Button onClick={handleSend} size="icon">
            <Send className="size-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
