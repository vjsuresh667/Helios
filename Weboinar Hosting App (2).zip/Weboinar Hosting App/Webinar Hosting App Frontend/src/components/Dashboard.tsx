import { Sparkles, TrendingUp, Calendar, Clock, Users, Play, ArrowRight, Target } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ScrollArea } from './ui/scroll-area';
import type { Webinar, User } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface DashboardProps {
  onViewWebinar: (webinar: Webinar) => void;
  onJoinLive: (webinar: Webinar) => void;
  onReplay: (webinar: Webinar) => void;
  user: User | null;
}

export function Dashboard({ onViewWebinar, onJoinLive, onReplay, user }: DashboardProps) {
  const upcomingWebinars: Webinar[] = [
    {
      id: '1',
      title: 'The Future of SEO: AI-Powered Strategies',
      description: 'Learn how to leverage AI tools to revolutionize your SEO approach and stay ahead of algorithm changes.',
      speaker: 'Alex Chen',
      speakerTitle: 'SEO Director at Google',
      date: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
      duration: '60 min',
      tags: ['SEO', 'Marketing', 'AI'],
      thumbnail: 'https://images.unsplash.com/photo-1432888622747-4eb9a8f2c293',
      status: 'live',
      registered: true,
      matchScore: 98,
    },
    {
      id: '2',
      title: 'Content Marketing for 2026: Trends & Tactics',
      description: 'Discover emerging content marketing trends and actionable strategies to engage your audience.',
      speaker: 'Sarah Johnson',
      speakerTitle: 'CMO at HubSpot',
      date: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
      duration: '45 min',
      tags: ['Content Marketing', 'Strategy', 'Marketing'],
      thumbnail: 'https://images.unsplash.com/photo-1557804506-669a67965ba0',
      status: 'upcoming',
      registered: true,
      matchScore: 95,
    },
    {
      id: '3',
      title: 'Social Media Analytics: Measuring What Matters',
      description: 'Master the art of social media measurement with advanced analytics frameworks and tools.',
      speaker: 'Michael Roberts',
      speakerTitle: 'Head of Analytics at Meta',
      date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days
      duration: '50 min',
      tags: ['Social Media', 'Analytics', 'Marketing'],
      thumbnail: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f',
      status: 'upcoming',
      matchScore: 92,
    },
    {
      id: '4',
      title: 'Email Marketing Automation with AI',
      description: 'Transform your email campaigns with intelligent automation and personalization at scale.',
      speaker: 'Emily Zhang',
      speakerTitle: 'Marketing Automation Lead',
      date: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days
      duration: '55 min',
      tags: ['Email Marketing', 'Automation', 'AI'],
      thumbnail: 'https://images.unsplash.com/photo-1563986768609-322da13575f3',
      status: 'upcoming',
      matchScore: 88,
    },
  ];

  const completedWebinars: Webinar[] = [
    {
      id: '5',
      title: 'Marketing Attribution Models Explained',
      description: 'Deep dive into various attribution models and how to choose the right one for your business.',
      speaker: 'Alex Chen',
      speakerTitle: 'SEO Director at Google',
      date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
      duration: '60 min',
      tags: ['Marketing', 'Analytics', 'Attribution'],
      thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71',
      status: 'completed',
      registered: true,
      recordingUrl: 'https://example.com/recording-1',
    },
    {
      id: '6',
      title: 'Building Your Personal Brand on LinkedIn',
      description: 'Strategies for thought leadership and professional networking on LinkedIn.',
      speaker: 'Sarah Johnson',
      speakerTitle: 'CMO at HubSpot',
      date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000), // 14 days ago
      duration: '45 min',
      tags: ['LinkedIn', 'Personal Branding', 'Social Media'],
      thumbnail: 'https://images.unsplash.com/photo-1611944212129-29977ae1398c',
      status: 'completed',
      registered: true,
      recordingUrl: 'https://example.com/recording-2',
    },
  ];

  const userInterests = [
    { name: 'SEO', score: 92, trending: true },
    { name: 'Content Marketing', score: 85, trending: false },
    { name: 'Digital Marketing', score: 78, trending: true },
    { name: 'Marketing Analytics', score: 65, trending: false },
  ];

  const liveWebinar = upcomingWebinars.find(w => w.status === 'live');

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-6 max-w-7xl mx-auto">
        {/* Helios Greeting */}
        <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border-2 border-yellow-200 dark:border-yellow-800">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="size-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg shrink-0">
                <Sparkles className="size-7 text-white" />
              </div>
              <div className="flex-1">
                <h2 className="mb-2">Good morning, {user?.name?.split(' ')[0] || 'there'}! ☀️</h2>
                <p className="text-muted-foreground mb-4">
                  Based on your interest in <span className="text-foreground">SEO</span> and <span className="text-foreground">Content Marketing</span>, 
                  I've curated 4 upcoming webinars that match your profile perfectly. 
                  Your next session "The Future of SEO" starts in <span className="text-foreground">2 hours</span>!
                </p>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary" className="gap-1">
                    <Target className="size-3" />
                    98% match for next webinar
                  </Badge>
                  <Badge variant="secondary" className="gap-1">
                    <TrendingUp className="size-3" />
                    Engagement up 23% this month
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Live Now Banner */}
        {liveWebinar && (
          <Card className="border-2 border-red-500 bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-950/20 dark:to-pink-950/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <div className="size-3 bg-red-500 rounded-full animate-pulse" />
                    <div className="absolute inset-0 size-3 bg-red-500 rounded-full animate-ping" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-red-500">LIVE NOW</span>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-muted-foreground">{liveWebinar.title}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {liveWebinar.speaker} • 247 attendees watching
                    </p>
                  </div>
                </div>
                <Button onClick={() => onJoinLive(liveWebinar)} size="lg" className="gap-2">
                  <Play className="size-4" />
                  Join Now
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="col-span-2 space-y-6">
            {/* Helios Recommendations */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="flex items-center gap-2">
                  <Sparkles className="size-5 text-yellow-500" />
                  Helios Recommendations
                </h2>
                <span className="text-sm text-muted-foreground">Personalized for you</span>
              </div>

              <div className="space-y-4">
                {upcomingWebinars.map((webinar) => (
                  <Card key={webinar.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="flex gap-4">
                      <div className="w-64 h-40 relative shrink-0">
                        <ImageWithFallback
                          src={webinar.thumbnail}
                          alt={webinar.title}
                          className="w-full h-full object-cover"
                        />
                        {webinar.matchScore && (
                          <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded text-xs flex items-center gap-1">
                            <Sparkles className="size-3" />
                            {webinar.matchScore}% Match
                          </div>
                        )}
                        {webinar.status === 'live' && (
                          <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs flex items-center gap-1">
                            <div className="size-2 bg-white rounded-full animate-pulse" />
                            LIVE
                          </div>
                        )}
                      </div>
                      <div className="flex-1 p-4 flex flex-col">
                        <div className="flex-1">
                          <h3 className="mb-2">{webinar.title}</h3>
                          <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                            {webinar.description}
                          </p>
                          <div className="flex items-center gap-3 text-sm text-muted-foreground mb-3">
                            <span>{webinar.speaker}</span>
                            <span>•</span>
                            <span>{webinar.speakerTitle}</span>
                          </div>
                          <div className="flex items-center gap-2 flex-wrap">
                            {webinar.tags.map(tag => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center justify-between mt-4">
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Calendar className="size-4" />
                              {webinar.date.toLocaleDateString()}
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="size-4" />
                              {webinar.duration}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {webinar.registered && (
                              <Badge variant="secondary">Registered</Badge>
                            )}
                            {webinar.status === 'live' ? (
                              <Button onClick={() => onJoinLive(webinar)} className="gap-2">
                                <Play className="size-4" />
                                Join Live
                              </Button>
                            ) : (
                              <Button onClick={() => onViewWebinar(webinar)} variant="outline" className="gap-2">
                                View Details
                                <ArrowRight className="size-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Interest Profile */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Target className="size-4" />
                  Your Interest Profile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Helios learns from your behavior to recommend the most relevant webinars.
                </p>
                {userInterests.map((interest) => (
                  <div key={interest.name}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{interest.name}</span>
                        {interest.trending && (
                          <TrendingUp className="size-3 text-green-500" />
                        )}
                      </div>
                      <span className="text-sm text-muted-foreground">{interest.score}%</span>
                    </div>
                    <Progress value={interest.score} className="h-2" />
                  </div>
                ))}
                <Button variant="outline" size="sm" className="w-full mt-4">
                  Update Interests
                </Button>
              </CardContent>
            </Card>

            {/* Engagement Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Users className="size-4" />
                  Your Engagement
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Webinars Attended</span>
                  <span className="text-xl">12</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Questions Asked</span>
                  <span className="text-xl">34</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Avg. Engagement</span>
                  <Badge variant="secondary">87%</Badge>
                </div>
                <div className="pt-3 border-t border-border">
                  <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
                    <TrendingUp className="size-4" />
                    <span>+23% vs last month</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Reminders */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Calendar className="size-4" />
                  Upcoming Reminders
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="size-2 bg-yellow-500 rounded-full" />
                    <span>T-2 hours: SEO webinar starts</span>
                  </div>
                  <p className="text-muted-foreground text-xs ml-4">
                    Helios sent you a preview video
                  </p>
                </div>
                <div className="text-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="size-2 bg-blue-500 rounded-full" />
                    <span>T-1 day: Content Marketing</span>
                  </div>
                  <p className="text-muted-foreground text-xs ml-4">
                    Speaker spotlight ready
                  </p>
                </div>
                <div className="text-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="size-2 bg-purple-500 rounded-full" />
                    <span>T-3 days: Social Analytics</span>
                  </div>
                  <p className="text-muted-foreground text-xs ml-4">
                    Preview scheduled
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Completed Webinars Section */}
        {completedWebinars.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2>Recently Completed Webinars</h2>
              <Button variant="outline" size="sm">
                View All Replays
              </Button>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {completedWebinars.map((webinar) => (
                <Card key={webinar.id} className="hover:shadow-lg transition-shadow">
                  <div className="flex gap-4">
                    <div className="w-40 h-32 relative shrink-0">
                      <ImageWithFallback
                        src={webinar.thumbnail}
                        alt={webinar.title}
                        className="w-full h-full object-cover rounded-l-lg"
                      />
                      <div className="absolute top-2 left-2 bg-green-600 text-white px-2 py-1 rounded text-xs">
                        COMPLETED
                      </div>
                    </div>
                    <div className="flex-1 p-4 flex flex-col">
                      <div className="flex-1">
                        <h4 className="mb-1">{webinar.title}</h4>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                          <span>{webinar.speaker}</span>
                          <span>•</span>
                          <span>{webinar.date.toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          {webinar.tags.slice(0, 2).map(tag => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <Button 
                        onClick={() => onReplay(webinar)} 
                        variant="outline" 
                        size="sm" 
                        className="w-full mt-3 gap-2"
                      >
                        <Play className="size-4" />
                        Watch Replay
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </ScrollArea>
  );
}
