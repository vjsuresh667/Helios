import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Lock } from 'lucide-react';
import { Button } from './ui/button';
import { WebinarHeader } from './WebinarHeader';
import { WebinarPlayer } from './WebinarPlayer';
import { ChatPanel } from './ChatPanel';
import { ParticipantList } from './ParticipantList';
import { QAPanel } from './QAPanel';
import { HeliosLivePanel } from './HeliosLivePanel';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import type { Webinar, UserType } from '../App';

interface LiveWebinarProps {
  webinar: Webinar;
  onBack: () => void;
  userType: UserType;
}

export function LiveWebinar({ webinar, onBack, userType }: LiveWebinarProps) {
  const [activeTab, setActiveTab] = useState('chat');
  const [isAIEnabled, setIsAIEnabled] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const isLive = webinar.status === 'live';

  // Handle media stream controls
  useEffect(() => {
    const updateMediaTracks = () => {
      if (mediaStreamRef.current) {
        // Toggle audio tracks
        mediaStreamRef.current.getAudioTracks().forEach(track => {
          track.enabled = !isMuted;
        });
        
        // Toggle video tracks
        mediaStreamRef.current.getVideoTracks().forEach(track => {
          track.enabled = !isVideoOff;
        });
      }
    };

    updateMediaTracks();
  }, [isMuted, isVideoOff]);

  return (
    <div className="size-full flex flex-col bg-background">
      {/* Header with Back Button */}
      <div className="border-b border-border px-6 py-3 flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="size-5" />
        </Button>
        <div className="flex-1">
          <WebinarHeader 
            webinar={webinar}
            isAIEnabled={isAIEnabled}
            onToggleAI={() => setIsAIEnabled(!isAIEnabled)}
            isMuted={isMuted}
            isVideoOff={isVideoOff}
            onToggleMute={() => setIsMuted(!isMuted)}
            onToggleVideo={() => setIsVideoOff(!isVideoOff)}
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Video Player */}
        <div className="flex-1 flex flex-col p-4 gap-4 overflow-hidden">
          <WebinarPlayer 
            webinar={webinar} 
            isMuted={isMuted}
            isVideoOff={isVideoOff}
            onMediaStreamReady={(stream) => { mediaStreamRef.current = stream; }}
          />
          <HeliosLivePanel isEnabled={isAIEnabled} webinar={webinar} />
        </div>

        {/* Right: Tabbed Sidebar */}
        <div className="w-96 border-l border-border flex flex-col">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <div className="border-b border-border px-4 pt-4">
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="chat">Chat</TabsTrigger>
                <TabsTrigger value="qa">Q&A</TabsTrigger>
                <TabsTrigger value="participants">
                  Participants
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="flex-1 overflow-hidden">
              <TabsContent value="chat" className="h-full m-0">
                {isLive ? (
                  <ChatPanel isAIEnabled={isAIEnabled} />
                ) : (
                  <div className="h-full flex items-center justify-center p-6">
                    <Alert>
                      <Lock className="size-4" />
                      <AlertDescription>
                        Chat will be available when the webinar goes live.
                        {userType === 'host' && ' Start the webinar to enable chat.'}
                      </AlertDescription>
                    </Alert>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="qa" className="h-full m-0">
                {isLive ? (
                  <QAPanel isAIEnabled={isAIEnabled} />
                ) : (
                  <div className="h-full flex items-center justify-center p-6">
                    <Alert>
                      <Lock className="size-4" />
                      <AlertDescription>
                        Q&A will be available when the webinar goes live.
                      </AlertDescription>
                    </Alert>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="participants" className="h-full m-0">
                <ParticipantList />
              </TabsContent>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
