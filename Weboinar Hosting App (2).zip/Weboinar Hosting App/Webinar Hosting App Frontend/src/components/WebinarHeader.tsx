import { Video, Mic, MicOff, VideoOff, Monitor, Settings, Users, Bot } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import type { Webinar } from '../App';

interface WebinarHeaderProps {
  webinar: Webinar;
  isAIEnabled: boolean;
  onToggleAI: () => void;
  isMuted?: boolean;
  isVideoOff?: boolean;
  onToggleMute?: () => void;
  onToggleVideo?: () => void;
}

export function WebinarHeader({ 
  webinar, 
  isAIEnabled, 
  onToggleAI,
  isMuted = false,
  isVideoOff = false,
  onToggleMute,
  onToggleVideo
}: WebinarHeaderProps) {

  return (
    <div className="flex items-center justify-between">
      {/* Left: Webinar Info */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="size-2 bg-red-500 rounded-full animate-pulse" />
          <span className="text-muted-foreground">LIVE</span>
        </div>
        <div>
          <h1 className="flex items-center gap-2">
            {webinar.title}
            {isAIEnabled && (
              <Badge variant="secondary" className="gap-1">
                <Bot className="size-3" />
                Helios Active
              </Badge>
            )}
          </h1>
          <div className="flex items-center gap-3 text-muted-foreground">
            <span className="flex items-center gap-1">
              <Users className="size-4" />
              247 attendees
            </span>
            <span>•</span>
            <span>{webinar.speaker}</span>
          </div>
        </div>
      </div>

      {/* Right: Controls */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-2 mr-4 px-3 py-2 bg-accent rounded-lg">
          <Label htmlFor="ai-toggle" className="cursor-pointer">Helios AI</Label>
          <Switch
            id="ai-toggle"
            checked={isAIEnabled}
            onCheckedChange={onToggleAI}
          />
        </div>

        <Button
          variant={isMuted ? "destructive" : "secondary"}
          size="icon"
          onClick={onToggleMute}
        >
          {isMuted ? <MicOff className="size-5" /> : <Mic className="size-5" />}
        </Button>

        <Button
          variant={isVideoOff ? "destructive" : "secondary"}
          size="icon"
          onClick={onToggleVideo}
        >
          {isVideoOff ? <VideoOff className="size-5" /> : <Video className="size-5" />}
        </Button>

        <Button variant="secondary" size="icon">
          <Monitor className="size-5" />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="secondary" size="icon">
              <Settings className="size-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>Recording Settings</DropdownMenuItem>
            <DropdownMenuItem>Audio/Video Settings</DropdownMenuItem>
            <DropdownMenuItem>Helios Configuration</DropdownMenuItem>
            <DropdownMenuItem>Webinar Settings</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button variant="destructive">
          End Webinar
        </Button>
      </div>
    </div>
  );
}
