import { useState } from 'react';
import { ArrowLeft, Sparkles, Mail, Lock, User, Building2, Globe } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { Separator } from '../ui/separator';
import { Checkbox } from '../ui/checkbox';
import { toast } from 'sonner@2.0.3';
import type { User as UserType } from '../../App';

interface HostLoginProps {
  onLogin: (user: UserType) => void;
  onBack: () => void;
}

export function HostLogin({ onLogin, onBack }: HostLoginProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    organization: '',
    website: '',
    agreeToTerms: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSignUp) {
      // Sign up flow
      if (!formData.name || !formData.email || !formData.password || !formData.organization) {
        toast.error('Please fill in all required fields');
        return;
      }
      
      if (!formData.agreeToTerms) {
        toast.error('Please agree to the terms and conditions');
        return;
      }
      
      toast.success('Host account created successfully! Start hosting with Helios AI.');
      onLogin({
        name: formData.name,
        email: formData.email,
        type: 'host',
        company: formData.organization,
      });
    } else {
      // Login flow
      if (!formData.email || !formData.password) {
        toast.error('Please enter your email and password');
        return;
      }
      
      toast.success('Welcome back! Ready to host amazing webinars.');
      // Using demo data for login
      onLogin({
        name: 'Sarah Johnson',
        email: formData.email,
        type: 'host',
        company: 'WebinarPro Inc.',
      });
    }
  };

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-orange-50 via-yellow-50 to-red-50 dark:from-orange-950/20 dark:via-yellow-950/20 dark:to-red-900/20">
      <div className="w-full max-w-md px-6">
        <Button variant="ghost" onClick={onBack} className="mb-6 gap-2">
          <ArrowLeft className="size-4" />
          Back
        </Button>

        <Card className="shadow-2xl">
          <CardHeader className="text-center pb-6">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="size-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
                <Sparkles className="size-7 text-white" />
              </div>
            </div>
            <CardTitle className="text-2xl">
              {isSignUp ? 'Create Host Account' : 'Host Login'}
            </CardTitle>
            <CardDescription>
              {isSignUp 
                ? 'Start hosting AI-powered webinars with Helios' 
                : 'Welcome back! Manage your webinars and engage your audience'}
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignUp && (
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                      id="name"
                      type="text"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="pl-10"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@company.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>

              {isSignUp && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="organization">Organization / Company *</Label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        id="organization"
                        type="text"
                        placeholder="Your company name"
                        value={formData.organization}
                        onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="website">Website (Optional)</Label>
                    <div className="relative">
                      <Globe className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        id="website"
                        type="url"
                        placeholder="https://yourcompany.com"
                        value={formData.website}
                        onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="flex items-start gap-3 pt-2">
                    <Checkbox
                      id="terms"
                      checked={formData.agreeToTerms}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, agreeToTerms: checked as boolean })
                      }
                      className="mt-1"
                    />
                    <Label htmlFor="terms" className="text-sm cursor-pointer leading-relaxed">
                      I agree to the Helios Terms of Service and acknowledge that my webinars will use AI for moderation, analytics, and attendee engagement
                    </Label>
                  </div>
                </>
              )}

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600" 
                size="lg"
              >
                {isSignUp ? 'Create Host Account' : 'Sign In'}
              </Button>

              <Separator />

              <div className="text-center text-sm">
                <span className="text-muted-foreground">
                  {isSignUp ? 'Already have an account?' : "Don't have an account?"}
                </span>
                {' '}
                <button
                  type="button"
                  onClick={() => setIsSignUp(!isSignUp)}
                  className="text-primary hover:underline"
                >
                  {isSignUp ? 'Sign In' : 'Sign Up'}
                </button>
              </div>
            </form>

            {isSignUp && (
              <div className="mt-6 space-y-3">
                <div className="p-4 bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                  <div className="flex items-start gap-2">
                    <Sparkles className="size-4 text-yellow-500 shrink-0 mt-0.5" />
                    <div className="space-y-2">
                      <p className="text-xs">
                        <span className="text-foreground">Helios AI Features for Hosts:</span>
                      </p>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        <li>• Automated chat moderation and spam filtering</li>
                        <li>• AI-powered Q&A prioritization</li>
                        <li>• Real-time engagement analytics</li>
                        <li>• Personalized post-webinar summaries for each attendee</li>
                        <li>• Automated follow-up email campaigns</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <p className="text-center text-xs text-muted-foreground mt-6">
          Protected by enterprise-grade security • SOC 2 Type II Certified
        </p>
      </div>
    </div>
  );
}