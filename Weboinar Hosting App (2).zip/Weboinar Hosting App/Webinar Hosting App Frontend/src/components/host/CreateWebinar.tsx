import { useState } from 'react';
import { ArrowLeft, Sparkles, Calendar, Clock, Tag, Image, Video, Save, Upload, X } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { toast } from 'sonner@2.0.3';
import type { User, Webinar, WebinarStatus } from '../../App';

interface CreateWebinarProps {
  user: User;
  onBack: () => void;
  onCreate: (webinar: Omit<Webinar, 'id'>) => void;
}

export function CreateWebinar({ user, onBack, onCreate }: CreateWebinarProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    duration: '60',
    tags: '',
    thumbnail: '',
  });

  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [currentTag, setCurrentTag] = useState('');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [thumbnailMethod, setThumbnailMethod] = useState<'upload' | 'url'>('upload');

  const suggestedTags = [
    'Marketing', 'SEO', 'AI', 'Technology', 'Product Launch', 
    'Sales', 'Customer Success', 'Data Science', 'Business', 'Strategy'
  ];

  const handleAddTag = (tag: string) => {
    if (tag && !selectedTags.includes(tag)) {
      setSelectedTags([...selectedTags, tag]);
      setCurrentTag('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setSelectedTags(selectedTags.filter(t => t !== tag));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast.error('Please upload an image file');
        return;
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Image size should be less than 5MB');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        toast.success('Image uploaded successfully');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setUploadedImage(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.description || !formData.date || !formData.time) {
      toast.error('Please fill in all required fields');
      return;
    }

    // Combine date and time
    const webinarDate = new Date(`${formData.date}T${formData.time}`);
    
    // Determine status based on date
    const now = new Date();
    let status: WebinarStatus = 'upcoming';
    if (webinarDate <= now && webinarDate.getTime() + parseInt(formData.duration) * 60 * 1000 > now.getTime()) {
      status = 'live';
    } else if (webinarDate.getTime() + parseInt(formData.duration) * 60 * 1000 <= now.getTime()) {
      status = 'completed';
    }

    // Determine thumbnail - prioritize uploaded image, then URL, then default
    let thumbnailUrl = 'https://images.unsplash.com/photo-1591115765373-5207764f72e7';
    if (thumbnailMethod === 'upload' && uploadedImage) {
      thumbnailUrl = uploadedImage;
    } else if (thumbnailMethod === 'url' && formData.thumbnail) {
      thumbnailUrl = formData.thumbnail;
    }

    const newWebinar: Omit<Webinar, 'id'> = {
      title: formData.title,
      description: formData.description,
      speaker: user.name,
      speakerTitle: user.role || 'Host',
      date: webinarDate,
      duration: `${formData.duration} min`,
      tags: selectedTags.length > 0 ? selectedTags : formData.tags.split(',').map(t => t.trim()).filter(Boolean),
      thumbnail: thumbnailUrl,
      status: status,
      registered: false,
    };

    onCreate(newWebinar);
    toast.success('Webinar created successfully! Helios AI is ready to assist.');
  };

  return (
    <ScrollArea className="h-full">
      <div className="p-6 max-w-4xl mx-auto">
        <div className="mb-6">
          <Button variant="ghost" onClick={onBack} className="gap-2 mb-4">
            <ArrowLeft className="size-4" />
            Back to Dashboard
          </Button>
          
          <div className="flex items-center gap-3 mb-2">
            <div className="size-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
              <Sparkles className="size-7 text-white" />
            </div>
            <div>
              <h1>Create New Webinar</h1>
              <p className="text-muted-foreground">Set up your webinar and let Helios AI handle the engagement</p>
            </div>
          </div>
        </div>

        <div className="grid gap-6">
          {/* AI Features Card */}
          <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border-yellow-200 dark:border-yellow-800">
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <Sparkles className="size-5 text-yellow-500 shrink-0 mt-0.5" />
                <div>
                  <h3 className="mb-2">Helios AI Features Enabled</h3>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="size-2 bg-green-500 rounded-full" />
                      <span>Automated chat moderation</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="size-2 bg-green-500 rounded-full" />
                      <span>Q&A prioritization</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="size-2 bg-green-500 rounded-full" />
                      <span>Real-time sentiment analysis</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="size-2 bg-green-500 rounded-full" />
                      <span>Personalized follow-ups</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Main Form */}
          <Card>
            <CardHeader>
              <CardTitle>Webinar Details</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Title */}
                <div className="space-y-2">
                  <Label htmlFor="title">Webinar Title *</Label>
                  <Input
                    id="title"
                    placeholder="e.g., The Future of AI in Marketing"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe what attendees will learn..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={4}
                  />
                </div>

                {/* Date and Time */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Date *</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        id="date"
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time">Time *</Label>
                    <div className="relative">
                      <Clock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        id="time"
                        type="time"
                        value={formData.time}
                        onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>

                {/* Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes) *</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                      id="duration"
                      type="number"
                      placeholder="60"
                      value={formData.duration}
                      onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                      className="pl-10"
                      min="15"
                      max="240"
                    />
                  </div>
                </div>

                {/* Tags */}
                <div className="space-y-3">
                  <Label>Tags</Label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        placeholder="Add a tag..."
                        value={currentTag}
                        onChange={(e) => setCurrentTag(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddTag(currentTag);
                          }
                        }}
                        className="pl-10"
                      />
                    </div>
                    <Button 
                      type="button" 
                      onClick={() => handleAddTag(currentTag)}
                      variant="outline"
                    >
                      Add
                    </Button>
                  </div>

                  {/* Selected Tags */}
                  {selectedTags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {selectedTags.map(tag => (
                        <Badge 
                          key={tag} 
                          variant="secondary"
                          className="gap-1 cursor-pointer hover:bg-destructive hover:text-destructive-foreground"
                          onClick={() => handleRemoveTag(tag)}
                        >
                          {tag}
                          <span className="ml-1">×</span>
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Suggested Tags */}
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Suggested tags:</p>
                    <div className="flex flex-wrap gap-2">
                      {suggestedTags.filter(tag => !selectedTags.includes(tag)).map(tag => (
                        <Badge 
                          key={tag} 
                          variant="outline"
                          className="cursor-pointer hover:bg-accent"
                          onClick={() => handleAddTag(tag)}
                        >
                          + {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Thumbnail */}
                <div className="space-y-3">
                  <Label>Webinar Thumbnail</Label>
                  
                  <Tabs value={thumbnailMethod} onValueChange={(v) => setThumbnailMethod(v as 'upload' | 'url')}>
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="upload">Upload Image</TabsTrigger>
                      <TabsTrigger value="url">Image URL</TabsTrigger>
                    </TabsList>

                    <TabsContent value="upload" className="space-y-3">
                      {uploadedImage ? (
                        <div className="relative">
                          <img 
                            src={uploadedImage} 
                            alt="Thumbnail preview" 
                            className="w-full h-48 object-cover rounded-lg border-2 border-border"
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="icon"
                            className="absolute top-2 right-2"
                            onClick={handleRemoveImage}
                          >
                            <X className="size-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors">
                          <Input
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="hidden"
                            id="thumbnail-upload"
                          />
                          <Label htmlFor="thumbnail-upload" className="cursor-pointer">
                            <div className="flex flex-col items-center gap-2">
                              <div className="size-12 bg-accent rounded-lg flex items-center justify-center">
                                <Upload className="size-6 text-muted-foreground" />
                              </div>
                              <div>
                                <p className="text-sm">Click to upload image</p>
                                <p className="text-xs text-muted-foreground">PNG, JPG up to 5MB</p>
                              </div>
                            </div>
                          </Label>
                        </div>
                      )}
                    </TabsContent>

                    <TabsContent value="url" className="space-y-2">
                      <div className="relative">
                        <Image className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                        <Input
                          id="thumbnail"
                          type="url"
                          placeholder="https://example.com/image.jpg"
                          value={formData.thumbnail}
                          onChange={(e) => setFormData({ ...formData, thumbnail: e.target.value })}
                          className="pl-10"
                        />
                      </div>
                      {formData.thumbnail && (
                        <div className="relative">
                          <img 
                            src={formData.thumbnail} 
                            alt="Thumbnail preview" 
                            className="w-full h-48 object-cover rounded-lg border-2 border-border"
                            onError={(e) => {
                              e.currentTarget.src = 'https://images.unsplash.com/photo-1591115765373-5207764f72e7';
                            }}
                          />
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                  
                  <p className="text-xs text-muted-foreground">Upload an image or provide a URL. Leave empty for default thumbnail.</p>
                </div>

                {/* Submit Buttons */}
                <div className="flex gap-3 pt-4">
                  <Button 
                    type="submit" 
                    className="flex-1 gap-2 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                    size="lg"
                  >
                    <Save className="size-4" />
                    Create Webinar
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={onBack}
                    size="lg"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Additional Settings Card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Advanced Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm">Recording</p>
                  <p className="text-xs text-muted-foreground">Automatically record this webinar</p>
                </div>
                <Badge variant="secondary">Enabled</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm">Chat Archive</p>
                  <p className="text-xs text-muted-foreground">Save chat messages for later review</p>
                </div>
                <Badge variant="secondary">Enabled</Badge>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm">AI-Generated Summaries</p>
                  <p className="text-xs text-muted-foreground">Send personalized summaries to attendees</p>
                </div>
                <Badge variant="secondary">Enabled</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </ScrollArea>
  );
}