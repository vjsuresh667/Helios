import { useState } from 'react';
import { ArrowLeft, Sparkles, Calendar, Clock, Tag, Image, Upload, X, Save, Trash2 } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '../ui/alert-dialog';
import { toast } from 'sonner@2.0.3';
import type { User, Webinar, WebinarStatus } from '../../App';

interface EditWebinarProps {
  user: User;
  webinar: Webinar;
  onBack: () => void;
  onUpdate: (id: string, webinar: Omit<Webinar, 'id'>) => void;
  onDelete: (id: string) => void;
}

export function EditWebinar({ user, webinar, onBack, onUpdate, onDelete }: EditWebinarProps) {
  // Parse the webinar date and time
  const webinarDate = new Date(webinar.date);
  const dateString = webinarDate.toISOString().split('T')[0];
  const timeString = webinarDate.toTimeString().slice(0, 5);
  const durationNum = parseInt(webinar.duration);

  const [formData, setFormData] = useState({
    title: webinar.title,
    description: webinar.description,
    date: dateString,
    time: timeString,
    duration: durationNum.toString(),
    thumbnail: webinar.thumbnail.startsWith('data:') ? '' : webinar.thumbnail,
  });

  const [selectedTags, setSelectedTags] = useState<string[]>(webinar.tags);
  const [currentTag, setCurrentTag] = useState('');
  const [uploadedImage, setUploadedImage] = useState<string | null>(
    webinar.thumbnail.startsWith('data:') ? webinar.thumbnail : null
  );
  const [thumbnailMethod, setThumbnailMethod] = useState<'upload' | 'url'>(
    webinar.thumbnail.startsWith('data:') ? 'upload' : 'url'
  );

  const suggestedTags = [
    'Marketing', 'SEO', 'AI', 'Technology', 'Product Launch', 
    'Sales', 'Customer Success', 'Data Science', 'Business', 'Strategy'
  ];

  const handleAddTag = (tag: string) => {
    if (tag && !selectedTags.includes(tag)) {
      setSelectedTags([...selectedTags, tag]);
      setCurrentTag('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setSelectedTags(selectedTags.filter(t => t !== tag));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast.error('Please upload an image file');
        return;
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Image size should be less than 5MB');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(reader.result as string);
        toast.success('Image uploaded successfully');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setUploadedImage(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.description || !formData.date || !formData.time) {
      toast.error('Please fill in all required fields');
      return;
    }

    // Combine date and time
    const webinarDate = new Date(`${formData.date}T${formData.time}`);
    
    // Determine status based on date
    const now = new Date();
    let status: WebinarStatus = 'upcoming';
    if (webinarDate <= now && webinarDate.getTime() + parseInt(formData.duration) * 60 * 1000 > now.getTime()) {
      status = 'live';
    } else if (webinarDate.getTime() + parseInt(formData.duration) * 60 * 1000 <= now.getTime()) {
      status = 'completed';
    }

    // Determine thumbnail - prioritize uploaded image, then URL, then default
    let thumbnailUrl = webinar.thumbnail; // Keep existing if nothing changed
    if (thumbnailMethod === 'upload' && uploadedImage) {
      thumbnailUrl = uploadedImage;
    } else if (thumbnailMethod === 'url' && formData.thumbnail) {
      thumbnailUrl = formData.thumbnail;
    }

    const updatedWebinar: Omit<Webinar, 'id'> = {
      title: formData.title,
      description: formData.description,
      speaker: user.name,
      speakerTitle: user.role || 'Host',
      date: webinarDate,
      duration: `${formData.duration} min`,
      tags: selectedTags,
      thumbnail: thumbnailUrl,
      status: status,
      registered: webinar.registered,
      matchScore: webinar.matchScore,
      recordingUrl: webinar.recordingUrl,
    };

    onUpdate(webinar.id, updatedWebinar);
    toast.success('Webinar updated successfully!');
  };

  const handleDelete = () => {
    onDelete(webinar.id);
    toast.success('Webinar deleted successfully');
  };

  return (
    <ScrollArea className="h-full">
      <div className="p-6 max-w-4xl mx-auto">
        <div className="mb-6">
          <Button variant="ghost" onClick={onBack} className="gap-2 mb-4">
            <ArrowLeft className="size-4" />
            Back to Dashboard
          </Button>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 mb-2">
              <div className="size-12 bg-gradient-to-br from-blue-400 to-purple-500 rounded-xl flex items-center justify-center shadow-lg">
                <Sparkles className="size-7 text-white" />
              </div>
              <div>
                <h1>Edit Webinar</h1>
                <p className="text-muted-foreground">Update your webinar details and settings</p>
              </div>
            </div>

            {/* Delete Button */}
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="gap-2">
                  <Trash2 className="size-4" />
                  Delete Webinar
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the webinar
                    "{webinar.title}" and remove all associated data.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        <div className="grid gap-6">
          {/* Status Badge */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Current Status:</span>
                  <Badge 
                    variant={webinar.status === 'live' ? 'default' : 'secondary'}
                    className={
                      webinar.status === 'live' 
                        ? 'bg-red-500' 
                        : webinar.status === 'completed' 
                        ? 'bg-green-600' 
                        : ''
                    }
                  >
                    {webinar.status.toUpperCase()}
                  </Badge>
                </div>
                <span className="text-sm text-muted-foreground">
                  Created: {new Date(webinar.date).toLocaleDateString()}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Main Form */}
          <Card>
            <CardHeader>
              <CardTitle>Webinar Details</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Title */}
                <div className="space-y-2">
                  <Label htmlFor="title">Webinar Title *</Label>
                  <Input
                    id="title"
                    placeholder="e.g., The Future of AI in Marketing"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </div>

                {/* Description */}
                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe what attendees will learn..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={4}
                  />
                </div>

                {/* Date and Time */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Date *</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        id="date"
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time">Time *</Label>
                    <div className="relative">
                      <Clock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        id="time"
                        type="time"
                        value={formData.time}
                        onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>

                {/* Duration */}
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes) *</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                      id="duration"
                      type="number"
                      placeholder="60"
                      value={formData.duration}
                      onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                      className="pl-10"
                      min="15"
                      max="240"
                    />
                  </div>
                </div>

                {/* Tags */}
                <div className="space-y-3">
                  <Label>Tags</Label>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        placeholder="Add a tag..."
                        value={currentTag}
                        onChange={(e) => setCurrentTag(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            handleAddTag(currentTag);
                          }
                        }}
                        className="pl-10"
                      />
                    </div>
                    <Button 
                      type="button" 
                      onClick={() => handleAddTag(currentTag)}
                      variant="outline"
                    >
                      Add
                    </Button>
                  </div>

                  {/* Selected Tags */}
                  {selectedTags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {selectedTags.map(tag => (
                        <Badge 
                          key={tag} 
                          variant="secondary"
                          className="gap-1 cursor-pointer hover:bg-destructive hover:text-destructive-foreground"
                          onClick={() => handleRemoveTag(tag)}
                        >
                          {tag}
                          <span className="ml-1">×</span>
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Suggested Tags */}
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Suggested tags:</p>
                    <div className="flex flex-wrap gap-2">
                      {suggestedTags.filter(tag => !selectedTags.includes(tag)).map(tag => (
                        <Badge 
                          key={tag} 
                          variant="outline"
                          className="cursor-pointer hover:bg-accent"
                          onClick={() => handleAddTag(tag)}
                        >
                          + {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Thumbnail */}
                <div className="space-y-3">
                  <Label>Webinar Thumbnail</Label>
                  
                  <Tabs value={thumbnailMethod} onValueChange={(v) => setThumbnailMethod(v as 'upload' | 'url')}>
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="upload">Upload Image</TabsTrigger>
                      <TabsTrigger value="url">Image URL</TabsTrigger>
                    </TabsList>

                    <TabsContent value="upload" className="space-y-3">
                      {uploadedImage ? (
                        <div className="relative">
                          <img 
                            src={uploadedImage} 
                            alt="Thumbnail preview" 
                            className="w-full h-48 object-cover rounded-lg border-2 border-border"
                          />
                          <Button
                            type="button"
                            variant="destructive"
                            size="icon"
                            className="absolute top-2 right-2"
                            onClick={handleRemoveImage}
                          >
                            <X className="size-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary transition-colors">
                          <Input
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="hidden"
                            id="thumbnail-upload-edit"
                          />
                          <Label htmlFor="thumbnail-upload-edit" className="cursor-pointer">
                            <div className="flex flex-col items-center gap-2">
                              <div className="size-12 bg-accent rounded-lg flex items-center justify-center">
                                <Upload className="size-6 text-muted-foreground" />
                              </div>
                              <div>
                                <p className="text-sm">Click to upload new image</p>
                                <p className="text-xs text-muted-foreground">PNG, JPG up to 5MB</p>
                              </div>
                            </div>
                          </Label>
                        </div>
                      )}
                    </TabsContent>

                    <TabsContent value="url" className="space-y-2">
                      <div className="relative">
                        <Image className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                        <Input
                          id="thumbnail"
                          type="url"
                          placeholder="https://example.com/image.jpg"
                          value={formData.thumbnail}
                          onChange={(e) => setFormData({ ...formData, thumbnail: e.target.value })}
                          className="pl-10"
                        />
                      </div>
                      {(formData.thumbnail || webinar.thumbnail) && (
                        <div className="relative">
                          <img 
                            src={formData.thumbnail || webinar.thumbnail} 
                            alt="Thumbnail preview" 
                            className="w-full h-48 object-cover rounded-lg border-2 border-border"
                            onError={(e) => {
                              e.currentTarget.src = 'https://images.unsplash.com/photo-1591115765373-5207764f72e7';
                            }}
                          />
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                  
                  <p className="text-xs text-muted-foreground">Update the thumbnail by uploading a new image or providing a URL.</p>
                </div>

                {/* Submit Buttons */}
                <div className="flex gap-3 pt-4">
                  <Button 
                    type="submit" 
                    className="flex-1 gap-2 bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
                    size="lg"
                  >
                    <Save className="size-4" />
                    Save Changes
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={onBack}
                    size="lg"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </ScrollArea>
  );
}