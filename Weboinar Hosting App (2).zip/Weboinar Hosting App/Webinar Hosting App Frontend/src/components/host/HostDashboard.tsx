import { Plus, Video, Users, TrendingUp, Calendar, BarChart3, Sparkles, Play, Settings, Edit } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { Progress } from '../ui/progress';
import type { User, Webinar } from '../../App';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface HostDashboardProps {
  user: User;
  onViewWebinar: (webinar: Webinar) => void;
  onCreateWebinar: () => void;
  onEditWebinar: (webinar: Webinar) => void;
  webinars: Webinar[];
}

export function HostDashboard({ user, onViewWebinar, onCreateWebinar, onEditWebinar, webinars }: HostDashboardProps) {
  const myWebinars: Webinar[] = webinars.length > 0 ? webinars : [
    {
      id: '1',
      title: 'AI-Powered Product Launch Webinar',
      description: 'Launch event for our new AI product suite',
      speaker: user.name,
      speakerTitle: 'Host',
      date: new Date(Date.now() + 2 * 60 * 60 * 1000),
      duration: '60 min',
      tags: ['Product Launch', 'AI', 'Technology'],
      thumbnail: 'https://images.unsplash.com/photo-1591115765373-5207764f72e7',
      status: 'live',
      registered: false,
    },
    {
      id: '2',
      title: 'Q4 Marketing Strategy Review',
      description: 'Quarterly review of marketing performance and future plans',
      speaker: user.name,
      speakerTitle: 'Host',
      date: new Date(Date.now() + 48 * 60 * 60 * 1000),
      duration: '45 min',
      tags: ['Marketing', 'Strategy', 'Business'],
      thumbnail: 'https://images.unsplash.com/photo-1557804506-669a67965ba0',
      status: 'upcoming',
      registered: false,
    },
    {
      id: '3',
      title: 'Customer Success Best Practices',
      description: 'Learn proven strategies for customer retention',
      speaker: user.name,
      speakerTitle: 'Host',
      date: new Date(Date.now() + 120 * 60 * 60 * 1000),
      duration: '50 min',
      tags: ['Customer Success', 'SaaS', 'Growth'],
      thumbnail: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0',
      status: 'upcoming',
      registered: false,
    },
  ];

  const liveWebinar = myWebinars.find(w => w.status === 'live');

  return (
    <ScrollArea className="h-full">
      <div className="p-6 space-y-6 max-w-7xl mx-auto">
        {/* Welcome Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="mb-2">Welcome back, {user.name}! 👋</h1>
            <p className="text-muted-foreground">
              Manage your webinars and leverage Helios AI to maximize engagement
            </p>
          </div>
          <Button 
            size="lg" 
            className="gap-2 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
            onClick={onCreateWebinar}
          >
            <Plus className="size-5" />
            Create New Webinar
          </Button>
        </div>

        {/* Live Webinar Alert */}
        {liveWebinar && (
          <Card className="border-2 border-red-500 bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-950/20 dark:to-pink-950/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <div className="size-3 bg-red-500 rounded-full animate-pulse" />
                    <div className="absolute inset-0 size-3 bg-red-500 rounded-full animate-ping" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-red-500">YOUR WEBINAR IS LIVE</span>
                      <span className="text-muted-foreground">•</span>
                      <span className="text-muted-foreground">{liveWebinar.title}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      247 attendees • Helios AI is actively moderating
                    </p>
                  </div>
                </div>
                <Button onClick={() => onViewWebinar(liveWebinar)} size="lg" className="gap-2">
                  <Play className="size-4" />
                  Go to Live Session
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stats Overview */}
        <div className="grid grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Total Webinars</span>
                <Video className="size-4 text-muted-foreground" />
              </div>
              <div className="text-3xl mb-1">12</div>
              <div className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                <TrendingUp className="size-3" />
                <span>+3 this month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Total Attendees</span>
                <Users className="size-4 text-muted-foreground" />
              </div>
              <div className="text-3xl mb-1">3,247</div>
              <div className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                <TrendingUp className="size-3" />
                <span>+18% vs last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Avg Engagement</span>
                <BarChart3 className="size-4 text-muted-foreground" />
              </div>
              <div className="text-3xl mb-1">87%</div>
              <div className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                <TrendingUp className="size-3" />
                <span>+12% with Helios</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border-yellow-200 dark:border-yellow-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-muted-foreground">Helios Actions</span>
                <Sparkles className="size-4 text-yellow-500" />
              </div>
              <div className="text-3xl mb-1">1,429</div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <span>AI assists this month</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-3 gap-6">
          {/* Main Content - My Webinars */}
          <div className="col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2>My Webinars</h2>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  Past Webinars
                </Button>
                <Button variant="outline" size="sm">
                  Analytics
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              {myWebinars.map((webinar) => (
                <Card key={`${webinar.id}-${webinar.thumbnail}`} className="hover:shadow-lg transition-shadow">
                  <div className="flex gap-4">
                    <div className="w-64 h-40 relative shrink-0">
                      <ImageWithFallback
                        key={webinar.thumbnail}
                        src={webinar.thumbnail}
                        alt={webinar.title}
                        className="w-full h-full object-cover rounded-l-lg"
                      />
                      {webinar.status === 'live' && (
                        <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs flex items-center gap-1">
                          <div className="size-2 bg-white rounded-full animate-pulse" />
                          LIVE
                        </div>
                      )}
                      {webinar.status === 'completed' && (
                        <div className="absolute top-2 left-2 bg-green-600 text-white px-2 py-1 rounded text-xs">
                          COMPLETED
                        </div>
                      )}
                    </div>
                    <div className="flex-1 p-4 flex flex-col">
                      <div className="flex-1">
                        <h3 className="mb-2">{webinar.title}</h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          {webinar.description}
                        </p>
                        <div className="flex items-center gap-2 flex-wrap">
                          {webinar.tags.map(tag => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="size-4" />
                            {webinar.date.toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="size-4" />
                            {webinar.status === 'live' ? '247 live' : '312 registered'}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="gap-2"
                            onClick={() => onEditWebinar(webinar)}
                          >
                            <Edit className="size-4" />
                            Edit
                          </Button>
                          {webinar.status === 'live' ? (
                            <Button onClick={() => onViewWebinar(webinar)} size="sm" className="gap-2">
                              <Play className="size-4" />
                              Go Live
                            </Button>
                          ) : (
                            <Button onClick={() => onViewWebinar(webinar)} variant="outline" size="sm">
                              View Details
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Helios AI Status */}
            <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border-yellow-200 dark:border-yellow-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Sparkles className="size-4 text-yellow-500" />
                  Helios AI Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Chat Moderation</span>
                    <Badge variant="secondary" className="text-xs">Active</Badge>
                  </div>
                  <Progress value={100} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Q&A Prioritization</span>
                    <Badge variant="secondary" className="text-xs">Active</Badge>
                  </div>
                  <Progress value={100} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Auto-Summarization</span>
                    <Badge variant="secondary" className="text-xs">Active</Badge>
                  </div>
                  <Progress value={100} className="h-2" />
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  Configure AI
                </Button>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="size-2 bg-green-500 rounded-full" />
                    <span>247 joined live session</span>
                  </div>
                  <p className="text-muted-foreground text-xs ml-4">2 minutes ago</p>
                </div>
                <div className="text-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="size-2 bg-blue-500 rounded-full" />
                    <span>Helios moderated 3 messages</span>
                  </div>
                  <p className="text-muted-foreground text-xs ml-4">5 minutes ago</p>
                </div>
                <div className="text-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="size-2 bg-purple-500 rounded-full" />
                    <span>85 new registrations</span>
                  </div>
                  <p className="text-muted-foreground text-xs ml-4">1 hour ago</p>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" size="sm" className="w-full justify-start gap-2">
                  <Video className="size-4" />
                  Schedule Webinar
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start gap-2">
                  <Users className="size-4" />
                  Invite Attendees
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start gap-2">
                  <BarChart3 className="size-4" />
                  View Analytics
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </ScrollArea>
  );
}