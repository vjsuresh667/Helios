import { useState, useEffect } from 'react';
import { Bot, TrendingUp, MessageSquare, Users, FileText, BarChart3, Sparkles } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ScrollArea } from './ui/scroll-area';

interface AIAssistantPanelProps {
  isEnabled: boolean;
}

export function AIAssistantPanel({ isEnabled }: AIAssistantPanelProps) {
  const [transcription, setTranscription] = useState<string[]>([
    "Welcome everyone to today's webinar on AI-powered product features.",
    "We're excited to show you how our platform can transform your workflow.",
    "Let's start by looking at the key benefits of automation.",
  ]);

  useEffect(() => {
    if (!isEnabled) return;

    const interval = setInterval(() => {
      const sampleTexts = [
        "The integration process is seamless and takes less than 5 minutes.",
        "Our AI can handle over 50 languages with real-time translation.",
        "Security and privacy are our top priorities in every feature.",
        "We've seen customers reduce their workflow time by 60%.",
      ];
      
      setTranscription(prev => {
        if (prev.length > 10) return prev;
        return [...prev, sampleTexts[Math.floor(Math.random() * sampleTexts.length)]];
      });
    }, 15000);

    return () => clearInterval(interval);
  }, [isEnabled]);

  if (!isEnabled) {
    return (
      <Card className="bg-muted/50">
        <CardContent className="p-6 flex flex-col items-center justify-center gap-3">
          <Bot className="size-12 text-muted-foreground" />
          <p className="text-muted-foreground text-center">
            AI Assistant is disabled. Enable it to access real-time insights.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-4">
      {/* Transcription */}
      <Card className="col-span-2">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <FileText className="size-5" />
            Live Transcription
            <Badge variant="secondary" className="ml-auto gap-1">
              <Sparkles className="size-3" />
              AI Powered
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-32">
            <div className="space-y-2">
              {transcription.map((text, i) => (
                <p
                  key={i}
                  className={`text-sm ${
                    i === transcription.length - 1
                      ? 'text-foreground'
                      : 'text-muted-foreground'
                  }`}
                >
                  {text}
                </p>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* AI Insights */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <BarChart3 className="size-4" />
            AI Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-muted-foreground">Engagement</span>
              <span className="text-sm">87%</span>
            </div>
            <Progress value={87} className="h-2" />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-muted-foreground">Sentiment</span>
              <Badge variant="secondary" className="text-xs">Positive</Badge>
            </div>
            <Progress value={92} className="h-2" />
          </div>
          <div className="pt-2 border-t border-border">
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="size-4 text-green-500" />
              <span className="text-muted-foreground">+23% vs last webinar</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <MessageSquare className="size-4" />
            Chat Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Messages</span>
              <span className="text-xl">127</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Questions</span>
              <span className="text-xl">23</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">AI Responses</span>
              <span className="text-xl">18</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Users className="size-4" />
            Attendance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Registered</span>
              <span className="text-xl">312</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Attending</span>
              <span className="text-xl">247</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Attendance Rate</span>
              <Badge variant="secondary">79%</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Bot className="size-4" />
            AI Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <div className="size-2 bg-green-500 rounded-full" />
              <span className="text-muted-foreground">Moderated 3 messages</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="size-2 bg-blue-500 rounded-full" />
              <span className="text-muted-foreground">Answered 18 questions</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="size-2 bg-purple-500 rounded-full" />
              <span className="text-muted-foreground">Flagged 2 priority Q&As</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
