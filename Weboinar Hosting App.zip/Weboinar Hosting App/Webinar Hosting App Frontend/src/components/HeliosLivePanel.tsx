import { useState, useEffect } from 'react';
import { Bot, TrendingUp, MessageSquare, Users, FileText, BarChart3, Sparkles, Brain, Zap, Target } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ScrollArea } from './ui/scroll-area';
import type { Webinar } from '../App';

interface HeliosLivePanelProps {
  isEnabled: boolean;
  webinar: Webinar;
}

export function HeliosLivePanel({ isEnabled, webinar }: HeliosLivePanelProps) {
  const [transcription, setTranscription] = useState<string[]>([
    `Welcome everyone to "${webinar.title}". I'm ${webinar.speaker}.`,
    "Let's start by looking at the key trends shaping our industry.",
    "I'll share practical strategies you can implement immediately.",
  ]);

  const [insights, setInsights] = useState({
    engagement: 87,
    sentiment: 92,
    attentionScore: 94,
  });

  useEffect(() => {
    if (!isEnabled) return;

    const transcriptInterval = setInterval(() => {
      const sampleTexts = [
        "This approach has helped our clients achieve remarkable results.",
        "Let me show you a real-world example from our recent case study.",
        "The data clearly demonstrates the impact of these techniques.",
        "I encourage you to ask questions as we go through this material.",
      ];
      
      setTranscription(prev => {
        if (prev.length > 12) return prev.slice(-11);
        return [...prev, sampleTexts[Math.floor(Math.random() * sampleTexts.length)]];
      });
    }, 12000);

    const insightsInterval = setInterval(() => {
      setInsights(prev => ({
        engagement: Math.min(100, Math.max(70, prev.engagement + (Math.random() - 0.5) * 5)),
        sentiment: Math.min(100, Math.max(70, prev.sentiment + (Math.random() - 0.5) * 3)),
        attentionScore: Math.min(100, Math.max(75, prev.attentionScore + (Math.random() - 0.5) * 4)),
      }));
    }, 8000);

    return () => {
      clearInterval(transcriptInterval);
      clearInterval(insightsInterval);
    };
  }, [isEnabled]);

  if (!isEnabled) {
    return (
      <Card className="bg-muted/50">
        <CardContent className="p-6 flex flex-col items-center justify-center gap-3">
          <div className="size-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg opacity-50">
            <Sparkles className="size-7 text-white" />
          </div>
          <p className="text-muted-foreground text-center">
            Helios AI is disabled. Enable it to access real-time insights and personalization.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-4">
      {/* Live Transcription */}
      <Card className="col-span-2">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <FileText className="size-5" />
            Live Transcription
            <Badge variant="secondary" className="ml-auto gap-1">
              <Sparkles className="size-3" />
              Helios Powered
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-32">
            <div className="space-y-2">
              {transcription.map((text, i) => (
                <p
                  key={i}
                  className={`text-sm ${
                    i === transcription.length - 1
                      ? 'text-foreground'
                      : 'text-muted-foreground'
                  }`}
                >
                  {text}
                </p>
              ))}
            </div>
          </ScrollArea>
          <div className="mt-3 pt-3 border-t border-border">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Brain className="size-3" />
              <span>Helios is analyzing content for your personalized summary</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Helios Real-Time Insights */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <BarChart3 className="size-4" />
            Real-Time Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-muted-foreground">Engagement</span>
              <span className="text-sm">{Math.round(insights.engagement)}%</span>
            </div>
            <Progress value={insights.engagement} className="h-2" />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-muted-foreground">Sentiment</span>
              <Badge variant="secondary" className="text-xs">Positive</Badge>
            </div>
            <Progress value={insights.sentiment} className="h-2" />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-muted-foreground">Attention</span>
              <span className="text-sm">{Math.round(insights.attentionScore)}%</span>
            </div>
            <Progress value={insights.attentionScore} className="h-2" />
          </div>
          <div className="pt-2 border-t border-border">
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="size-4 text-green-500" />
              <span className="text-muted-foreground">+18% vs avg</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Helios Actions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Zap className="size-4 text-yellow-500" />
            Helios Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-2">
              <div className="size-2 bg-green-500 rounded-full mt-1.5 shrink-0" />
              <div>
                <p>Moderated 3 messages</p>
                <p className="text-xs text-muted-foreground">Auto-flagged spam</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="size-2 bg-blue-500 rounded-full mt-1.5 shrink-0" />
              <div>
                <p>Answered 18 questions</p>
                <p className="text-xs text-muted-foreground">In chat automatically</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="size-2 bg-purple-500 rounded-full mt-1.5 shrink-0" />
              <div>
                <p>Prioritized 5 Q&As</p>
                <p className="text-xs text-muted-foreground">High-value topics</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <div className="size-2 bg-yellow-500 rounded-full mt-1.5 shrink-0" />
              <div>
                <p>Building your summary</p>
                <p className="text-xs text-muted-foreground">Tailored to your role</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Personalization Status */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Target className="size-4 text-yellow-500" />
            Your Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-sm">
            <p className="text-muted-foreground mb-2">Helios is customizing this experience for:</p>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">Marketing Manager</Badge>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {webinar.tags.map(tag => (
                  <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                ))}
              </div>
            </div>
          </div>
          <div className="pt-3 border-t border-border">
            <p className="text-xs text-muted-foreground">
              Your post-webinar summary will focus on <span className="text-foreground">actionable marketing strategies</span> and <span className="text-foreground">ROI metrics</span>.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Chat Activity */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <MessageSquare className="size-4" />
            Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Messages</span>
              <span className="text-xl">127</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Questions</span>
              <span className="text-xl">23</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Helios Responses</span>
              <span className="text-xl">18</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
