import { Home, Calendar, User, Sparkles, Bell, LogOut } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import type { View, User as UserType } from '../App';

interface NavigationProps {
  currentView: View;
  onNavigate: (view: View) => void;
  user: UserType | null;
  onLogout: () => void;
}

export function Navigation({ currentView, onNavigate, user, onLogout }: NavigationProps) {
  return (
    <div className="border-b border-border bg-card">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Brand */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="size-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center shadow-lg">
                <Sparkles className="size-6 text-white" />
              </div>
              <div>
                <h1 className="flex items-center gap-2">
                  Helios
                  <Badge variant="secondary" className="text-xs">AI-Powered</Badge>
                </h1>
                <p className="text-xs text-muted-foreground">Webinar Intelligence Platform</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center gap-2">
            <Button
              variant={currentView === 'dashboard' ? 'secondary' : 'ghost'}
              onClick={() => onNavigate('dashboard')}
              className="gap-2"
            >
              <Home className="size-4" />
              Dashboard
            </Button>
            <Button
              variant={currentView === 'profile' ? 'secondary' : 'ghost'}
              onClick={() => onNavigate('profile')}
              className="gap-2"
            >
              <Calendar className="size-4" />
              My Webinars
            </Button>
          </div>

          {/* User Area */}
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="size-5" />
              <div className="absolute top-1 right-1 size-2 bg-red-500 rounded-full" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 px-3 py-2 rounded-lg bg-accent hover:bg-accent/80 transition-colors">
                  <Avatar className="size-8">
                    <AvatarFallback>{user?.name.charAt(0) || 'U'}</AvatarFallback>
                  </Avatar>
                  <div className="text-sm text-left">
                    <div>{user?.name || 'User'}</div>
                    <div className="text-xs text-muted-foreground">
                      {user?.role || user?.company || 'User'}
                    </div>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem>
                  <User className="size-4 mr-2" />
                  Profile Settings
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Sparkles className="size-4 mr-2" />
                  AI Preferences
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onLogout} className="text-destructive">
                  <LogOut className="size-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </div>
  );
}
