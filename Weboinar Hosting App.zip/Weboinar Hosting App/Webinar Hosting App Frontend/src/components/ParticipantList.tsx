import { Crown, Hand, Mic, Video, MoreVertical, Shield, Bot } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { Input } from './ui/input';
import { useState } from 'react';

interface Participant {
  id: string;
  name: string;
  avatar?: string;
  role: 'host' | 'moderator' | 'attendee';
  handRaised?: boolean;
  micOn?: boolean;
  videoOn?: boolean;
  engagement?: number;
}

export function ParticipantList() {
  const [searchQuery, setSearchQuery] = useState('');
  const [participants] = useState<Participant[]>([
    {
      id: '1',
      name: 'Sarah Johnson',
      role: 'host',
      micOn: true,
      videoOn: true,
      engagement: 98,
    },
    {
      id: '2',
      name: 'AI Assistant',
      role: 'moderator',
      engagement: 100,
    },
    {
      id: '3',
      name: 'Alex Chen',
      role: 'attendee',
      handRaised: true,
      engagement: 95,
    },
    {
      id: '4',
      name: 'Maria Garcia',
      role: 'attendee',
      engagement: 87,
    },
    {
      id: '5',
      name: 'John Smith',
      role: 'attendee',
      handRaised: true,
      engagement: 92,
    },
    {
      id: '6',
      name: 'Emma Wilson',
      role: 'attendee',
      engagement: 78,
    },
    {
      id: '7',
      name: 'David Lee',
      role: 'attendee',
      engagement: 85,
    },
    {
      id: '8',
      name: 'Lisa Anderson',
      role: 'moderator',
      engagement: 96,
    },
  ]);

  const filteredParticipants = participants.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedParticipants = [...filteredParticipants].sort((a, b) => {
    if (a.role === 'host') return -1;
    if (b.role === 'host') return 1;
    if (a.role === 'moderator' && b.role !== 'moderator') return -1;
    if (b.role === 'moderator' && a.role !== 'moderator') return 1;
    if (a.handRaised !== b.handRaised) return a.handRaised ? -1 : 1;
    return (b.engagement || 0) - (a.engagement || 0);
  });

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-border space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">{participants.length} participants</span>
          <Badge variant="secondary" className="gap-1">
            <Bot className="size-3" />
            AI Tracking
          </Badge>
        </div>
        <Input
          placeholder="Search participants..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-2">
          {sortedParticipants.map((participant) => (
            <div
              key={participant.id}
              className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent transition-colors"
            >
              <div className="relative">
                <Avatar className="size-10">
                  <AvatarImage src={participant.avatar} />
                  <AvatarFallback>
                    {participant.name === 'AI Assistant' ? (
                      <Bot className="size-5" />
                    ) : (
                      participant.name.charAt(0)
                    )}
                  </AvatarFallback>
                </Avatar>
                {participant.handRaised && (
                  <div className="absolute -top-1 -right-1 bg-yellow-500 rounded-full p-1">
                    <Hand className="size-3 text-white" />
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm truncate">{participant.name}</span>
                  {participant.role === 'host' && (
                    <Crown className="size-4 text-yellow-500 shrink-0" />
                  )}
                  {participant.role === 'moderator' && participant.name !== 'AI Assistant' && (
                    <Shield className="size-4 text-blue-500 shrink-0" />
                  )}
                  {participant.name === 'AI Assistant' && (
                    <Badge variant="secondary" className="text-xs">AI</Badge>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full ${
                        (participant.engagement || 0) > 80
                          ? 'bg-green-500'
                          : (participant.engagement || 0) > 60
                          ? 'bg-yellow-500'
                          : 'bg-red-500'
                      }`}
                      style={{ width: `${participant.engagement || 0}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {participant.engagement}%
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1">
                {participant.micOn && (
                  <div className="size-6 flex items-center justify-center">
                    <Mic className="size-4 text-green-500" />
                  </div>
                )}
                {participant.videoOn && (
                  <div className="size-6 flex items-center justify-center">
                    <Video className="size-4 text-green-500" />
                  </div>
                )}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="size-6">
                      <MoreVertical className="size-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>View Profile</DropdownMenuItem>
                    <DropdownMenuItem>Send Private Message</DropdownMenuItem>
                    <DropdownMenuItem>Make Moderator</DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive">
                      Remove from Webinar
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
