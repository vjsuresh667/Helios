import { useState } from 'react';
import { ThumbsUp, Bot, TrendingUp, Clock, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';

interface Question {
  id: string;
  user: string;
  question: string;
  upvotes: number;
  timestamp: Date;
  answered?: boolean;
  aiSuggestion?: string;
  priority?: 'high' | 'medium' | 'low';
}

interface QAPanelProps {
  isAIEnabled: boolean;
}

export function QAPanel({ isAIEnabled }: QAPanelProps) {
  const [questions, setQuestions] = useState<Question[]>([
    {
      id: '1',
      user: 'Emma Wilson',
      question: 'How does the AI handle multiple languages in real-time?',
      upvotes: 15,
      timestamp: new Date(Date.now() - 600000),
      aiSuggestion: 'This is a popular topic. Consider addressing translation capabilities and NLP models used.',
      priority: 'high',
    },
    {
      id: '2',
      user: 'David Lee',
      question: 'What are the pricing plans for enterprise customers?',
      upvotes: 12,
      timestamp: new Date(Date.now() - 480000),
      aiSuggestion: 'Financial question detected. Suggest sharing pricing page link and scheduling follow-up.',
      priority: 'high',
    },
    {
      id: '3',
      user: 'Sarah Johnson',
      question: 'Can this integrate with existing LMS platforms?',
      upvotes: 8,
      timestamp: new Date(Date.now() - 360000),
      answered: true,
      priority: 'medium',
    },
    {
      id: '4',
      user: 'Michael Brown',
      question: 'How is the data encrypted and stored?',
      upvotes: 6,
      timestamp: new Date(Date.now() - 240000),
      aiSuggestion: 'Security concern. High priority for enterprise audience.',
      priority: 'high',
    },
  ]);
  const [newQuestion, setNewQuestion] = useState('');

  const handleSubmit = () => {
    if (!newQuestion.trim()) return;

    const question: Question = {
      id: Date.now().toString(),
      user: 'You',
      question: newQuestion,
      upvotes: 0,
      timestamp: new Date(),
    };

    // AI priority detection
    if (isAIEnabled) {
      const lowerQ = newQuestion.toLowerCase();
      if (lowerQ.includes('security') || lowerQ.includes('price') || lowerQ.includes('pricing')) {
        question.priority = 'high';
        question.aiSuggestion = 'High-priority topic detected. Recommend addressing soon.';
      } else {
        question.priority = 'medium';
      }
    }

    setQuestions([question, ...questions]);
    setNewQuestion('');
  };

  const handleUpvote = (id: string) => {
    setQuestions(questions.map(q =>
      q.id === id ? { ...q, upvotes: q.upvotes + 1 } : q
    ));
  };

  const sortedQuestions = [...questions].sort((a, b) => {
    if (a.answered !== b.answered) return a.answered ? 1 : -1;
    return b.upvotes - a.upvotes;
  });

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-border">
        <div className="flex gap-2">
          <Input
            placeholder="Ask a question..."
            value={newQuestion}
            onChange={(e) => setNewQuestion(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
          />
          <Button onClick={handleSubmit}>Ask</Button>
        </div>
        {isAIEnabled && (
          <div className="mt-2 text-xs text-muted-foreground flex items-center gap-1">
            <Bot className="size-3" />
            AI will auto-prioritize your question
          </div>
        )}
      </div>

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-3">
          {sortedQuestions.map((q) => (
            <div
              key={q.id}
              className={`p-3 rounded-lg border border-border bg-card ${
                q.answered ? 'opacity-60' : ''
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="flex flex-col items-center gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="size-8"
                    onClick={() => handleUpvote(q.id)}
                    disabled={q.answered}
                  >
                    <ThumbsUp className="size-4" />
                  </Button>
                  <span className="text-sm">{q.upvotes}</span>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Avatar className="size-6">
                      <AvatarFallback className="text-xs">
                        {q.user.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm">{q.user}</span>
                    {q.answered && (
                      <Badge variant="secondary" className="text-xs gap-1">
                        <CheckCircle className="size-3" />
                        Answered
                      </Badge>
                    )}
                    {q.priority === 'high' && isAIEnabled && !q.answered && (
                      <Badge variant="destructive" className="text-xs gap-1">
                        <TrendingUp className="size-3" />
                        High Priority
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm mb-2">{q.question}</p>
                  
                  {q.aiSuggestion && isAIEnabled && !q.answered && (
                    <div className="mt-2 p-2 bg-accent rounded text-xs flex items-start gap-2">
                      <Bot className="size-3 mt-0.5 shrink-0" />
                      <span className="text-muted-foreground">{q.aiSuggestion}</span>
                    </div>
                  )}

                  <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                    <Clock className="size-3" />
                    {q.timestamp.toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
