import { ArrowLeft, Calendar, Clock, Users, Play, Sparkles, Mail, Download, Share2, CheckCircle, Target } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import type { Webinar } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface WebinarDetailsProps {
  webinar: Webinar;
  onBack: () => void;
  onJoinLive: (webinar: Webinar) => void;
  onReplay: (webinar: Webinar) => void;
}

export function WebinarDetails({ webinar, onBack, onJoinLive, onReplay }: WebinarDetailsProps) {
  const timeUntilStart = webinar.date.getTime() - Date.now();
  const daysUntil = Math.floor(timeUntilStart / (1000 * 60 * 60 * 24));
  const hoursUntil = Math.floor((timeUntilStart % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

  return (
    <ScrollArea className="h-full">
      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Back Button */}
        <Button variant="ghost" onClick={onBack} className="gap-2">
          <ArrowLeft className="size-4" />
          Back to Dashboard
        </Button>

        {/* Hero Section */}
        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2 space-y-4">
            <div className="aspect-video rounded-lg overflow-hidden">
              <ImageWithFallback
                src={webinar.thumbnail}
                alt={webinar.title}
                className="w-full h-full object-cover"
              />
            </div>

            {webinar.matchScore && (
              <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border-yellow-200 dark:border-yellow-800">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="size-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center shrink-0">
                      <Sparkles className="size-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3>Helios Recommendation</h3>
                        <Badge variant="secondary" className="gap-1">
                          <Target className="size-3" />
                          {webinar.matchScore}% Match
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        This webinar aligns perfectly with your interests in {webinar.tags.slice(0, 2).join(' and ')}. 
                        Helios predicts high relevance to your Marketing Manager role.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div>
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h1 className="mb-3">{webinar.title}</h1>
                  <div className="flex items-center gap-2 flex-wrap mb-3">
                    {webinar.tags.map(tag => (
                      <Badge key={tag} variant="secondary">{tag}</Badge>
                    ))}
                  </div>
                </div>
              </div>

              <p className="text-muted-foreground mb-6">
                {webinar.description}
              </p>

              {/* What You'll Learn */}
              <div className="space-y-4">
                <h3>What You'll Learn</h3>
                <div className="grid gap-3">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="size-5 text-green-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="mb-1">Master advanced techniques</p>
                      <p className="text-sm text-muted-foreground">
                        Learn industry-leading strategies from an expert practitioner
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="size-5 text-green-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="mb-1">Actionable frameworks</p>
                      <p className="text-sm text-muted-foreground">
                        Get practical tools you can implement immediately
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="size-5 text-green-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="mb-1">Real-world case studies</p>
                      <p className="text-sm text-muted-foreground">
                        See successful implementations with measurable results
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="size-5 text-green-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="mb-1">Live Q&A session</p>
                      <p className="text-sm text-muted-foreground">
                        Get your specific questions answered by the speaker
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Registration Card */}
            <Card>
              <CardContent className="p-6 space-y-4">
                {webinar.status === 'live' ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <div className="size-3 bg-red-500 rounded-full animate-pulse" />
                      <span className="text-red-500">LIVE NOW</span>
                    </div>
                    <Button onClick={() => onJoinLive(webinar)} size="lg" className="w-full gap-2">
                      <Play className="size-4" />
                      Join Live Session
                    </Button>
                  </div>
                ) : webinar.status === 'completed' ? (
                  <div className="space-y-4">
                    <div>
                      <Badge variant="secondary" className="mb-2">Completed</Badge>
                      <p className="text-sm text-muted-foreground">
                        This webinar was recorded on {webinar.date.toLocaleDateString()}
                      </p>
                    </div>
                    {webinar.registered && (
                      <Button onClick={() => onReplay(webinar)} size="lg" className="w-full gap-2">
                        <Play className="size-4" />
                        Watch Replay
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">Starts in</p>
                      <p className="text-2xl">
                        {daysUntil > 0 ? `${daysUntil}d ${hoursUntil}h` : `${hoursUntil}h`}
                      </p>
                    </div>
                    {webinar.registered ? (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                          <CheckCircle className="size-5" />
                          <span>You're registered!</span>
                        </div>
                        <Button variant="outline" size="lg" className="w-full gap-2">
                          <Mail className="size-4" />
                          Add to Calendar
                        </Button>
                      </div>
                    ) : (
                      <Button size="lg" className="w-full">
                        Register Now
                      </Button>
                    )}
                  </div>
                )}

                <Separator />

                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className="size-4 text-muted-foreground" />
                    <span>{webinar.date.toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      month: 'long', 
                      day: 'numeric',
                      year: 'numeric'
                    })}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="size-4 text-muted-foreground" />
                    <span>{webinar.date.toLocaleTimeString('en-US', { 
                      hour: '2-digit', 
                      minute: '2-digit'
                    })} • {webinar.duration}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="size-4 text-muted-foreground" />
                    <span>312 registered</span>
                  </div>
                </div>

                <Separator />

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1 gap-2">
                    <Share2 className="size-4" />
                    Share
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1 gap-2">
                    <Download className="size-4" />
                    Save
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Speaker Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">About the Speaker</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <Avatar className="size-12">
                    <AvatarFallback>{webinar.speaker.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p>{webinar.speaker}</p>
                    <p className="text-sm text-muted-foreground">{webinar.speakerTitle}</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  A recognized expert with over 10 years of experience in the field. 
                  Known for delivering actionable insights and practical strategies.
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  View Full Bio
                </Button>
              </CardContent>
            </Card>

            {/* Helios Features */}
            <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 dark:from-yellow-950/20 dark:to-orange-950/20 border-yellow-200 dark:border-yellow-800">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Sparkles className="size-4 text-yellow-500" />
                  Helios Features
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <CheckCircle className="size-4 text-green-500 shrink-0 mt-0.5" />
                  <span>AI-powered live transcription</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="size-4 text-green-500 shrink-0 mt-0.5" />
                  <span>Personalized post-webinar summary tailored to your role</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="size-4 text-green-500 shrink-0 mt-0.5" />
                  <span>Smart Q&A prioritization</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="size-4 text-green-500 shrink-0 mt-0.5" />
                  <span>Real-time engagement analytics</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </ScrollArea>
  );
}
