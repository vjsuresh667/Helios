import { Play, Pause, Volume2, Maximize, Presentation, CameraOff, AlertCircle, MicOff } from 'lucide-react';
import { Button } from './ui/button';
import { Slider } from './ui/slider';
import { useState, useEffect, useRef } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Alert, AlertDescription } from './ui/alert';
import type { Webinar } from '../App';

interface WebinarPlayerProps {
  webinar: Webinar;
  isMuted?: boolean;
  isVideoOff?: boolean;
  onMediaStreamReady?: (stream: MediaStream) => void;
}

export function WebinarPlayer({ webinar, isMuted = false, isVideoOff = false, onMediaStreamReady }: WebinarPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [volume, setVolume] = useState([80]);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const presentationVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;

    const initCamera = async () => {
      try {
        // Request camera and audio access
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }, 
          audio: true 
        });

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }

        // Simulate presentation screen (could be screen sharing in real implementation)
        if (presentationVideoRef.current) {
          presentationVideoRef.current.srcObject = stream;
          presentationVideoRef.current.play();
        }

        // Notify parent component
        if (onMediaStreamReady) {
          onMediaStreamReady(stream);
        }

        setCameraError(null);
      } catch (err) {
        console.error('Error accessing camera:', err);
        setCameraError('Unable to access camera. Please check your permissions.');
      }
    };

    initCamera();

    // Cleanup function
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [onMediaStreamReady]);

  // Handle volume changes
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = volume[0] / 100;
      videoRef.current.muted = isMuted;
    }
    if (presentationVideoRef.current) {
      presentationVideoRef.current.volume = 0; // Mute presentation video to avoid echo
    }
  }, [volume, isMuted]);

  return (
    <div className="flex-1 bg-black rounded-lg overflow-hidden relative group">
      {/* Video/Presentation Area */}
      <div className="absolute inset-0 flex items-center justify-center">
        {/* Main presentation video */}
        <video
          ref={presentationVideoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-cover"
        />
        
        {/* Fallback image if camera is disabled */}
        {isVideoOff && (
          <div className="absolute inset-0 bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center">
            <ImageWithFallback
              src={webinar.thumbnail}
              alt="Webinar presentation"
              className="w-full h-full object-cover opacity-50"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <CameraOff className="size-16 text-white/50 mx-auto mb-4" />
                <p className="text-white/70">Camera is turned off</p>
              </div>
            </div>
          </div>
        )}
        
        {/* Speaker camera overlay (picture-in-picture) */}
        <div className="absolute bottom-4 right-4 w-48 h-36 rounded-lg overflow-hidden border-2 border-white shadow-lg bg-gray-900">
          {!isVideoOff && !cameraError ? (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover mirror"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent px-2 py-1">
                <div className="flex items-center justify-between">
                  <span className="text-white text-sm">{webinar.speaker}</span>
                  {isMuted && (
                    <MicOff className="size-3 text-red-400" />
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-3">
              <CameraOff className="size-8 text-white/50 mb-2" />
              <span className="text-white/70 text-xs text-center">
                {cameraError ? 'Camera Error' : 'Camera Off'}
              </span>
            </div>
          )}
        </div>

        {/* Camera error alert */}
        {cameraError && (
          <div className="absolute top-4 left-4 right-4 max-w-md">
            <Alert variant="destructive">
              <AlertCircle className="size-4" />
              <AlertDescription>{cameraError}</AlertDescription>
            </Alert>
          </div>
        )}

        {/* Presentation indicator */}
        <div className="absolute top-4 left-4 bg-black/80 backdrop-blur-sm px-3 py-2 rounded-lg flex items-center gap-2">
          <Presentation className="size-4 text-white" />
          <span className="text-white text-sm">Live Presentation</span>
        </div>
      </div>

      {/* Controls Overlay */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? <Pause className="size-5" /> : <Play className="size-5" />}
          </Button>

          <div className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden cursor-pointer">
            <div className="h-full bg-white w-1/3" />
          </div>

          <div className="flex items-center gap-2 min-w-32">
            <Volume2 className="size-4 text-white" />
            <Slider
              value={volume}
              onValueChange={setVolume}
              max={100}
              step={1}
              className="flex-1"
            />
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
          >
            <Maximize className="size-5" />
          </Button>
        </div>
      </div>

      <style>{`
        .mirror {
          transform: scaleX(-1);
        }
      `}</style>
    </div>
  );
}
