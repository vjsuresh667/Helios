import { useState } from 'react';
import { ArrowLeft, Play, Pause, SkipForward, SkipBack, Volume2, Maximize, Download, Share2, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Slider } from './ui/slider';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import type { Webinar } from '../App';

interface WebinarReplayProps {
  webinar: Webinar;
  onBack: () => void;
}

export function WebinarReplay({ webinar, onBack }: WebinarReplayProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(80);

  const aiSummary = {
    keyPoints: [
      'AI-powered SEO strategies can increase organic traffic by up to 40%',
      'Focus on semantic search and user intent rather than just keywords',
      'Machine learning algorithms can predict trending topics before they peak',
      'Automation tools can save 15+ hours per week on routine SEO tasks',
    ],
    actionItems: [
      'Audit current SEO strategy for AI integration opportunities',
      'Implement semantic keyword research using AI tools',
      'Set up automated content optimization workflows',
      'Test AI-powered competitor analysis platforms',
    ],
    resources: [
      { name: 'SEO AI Tools Comparison Guide', url: '#' },
      { name: 'Webinar Slides (PDF)', url: '#' },
      { name: 'Q&A Transcript', url: '#' },
    ],
  };

  const chatHighlights = [
    { time: '5:23', user: 'Sarah J.', message: 'This is game-changing for our team!', sentiment: 'positive' },
    { time: '12:45', user: 'Michael R.', message: 'How does this integrate with Google Analytics?', sentiment: 'question' },
    { time: '23:10', user: 'Emma L.', message: 'Best webinar I\'ve attended this year', sentiment: 'positive' },
    { time: '34:52', user: 'David K.', message: 'Can you share the case study details?', sentiment: 'question' },
  ];

  return (
    <div className="size-full flex flex-col bg-background">
      {/* Header */}
      <div className="border-b border-border px-6 py-4">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="size-5" />
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h2>{webinar.title}</h2>
              <Badge variant="secondary" className="gap-1">
                <Play className="size-3" />
                Replay
              </Badge>
            </div>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <span>{webinar.speaker}</span>
              <span>•</span>
              <span>Recorded on {webinar.date.toLocaleDateString()}</span>
              <span>•</span>
              <span>{webinar.duration}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="size-4" />
              Download
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Share2 className="size-4" />
              Share
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Video Player */}
        <div className="flex-1 flex flex-col p-6 gap-6 overflow-hidden">
          {/* Video Display */}
          <Card className="flex-1 overflow-hidden">
            <div className="size-full bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center relative">
              {/* Video Placeholder */}
              <div className="text-center">
                <div className="size-20 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center mb-4 mx-auto cursor-pointer hover:bg-white/20 transition-colors"
                     onClick={() => setIsPlaying(!isPlaying)}>
                  {isPlaying ? (
                    <Pause className="size-10 text-white" />
                  ) : (
                    <Play className="size-10 text-white ml-1" />
                  )}
                </div>
                <p className="text-white/80 text-lg">Webinar Recording</p>
                <p className="text-white/60 text-sm mt-1">{webinar.duration}</p>
              </div>

              {/* Helios AI Badge */}
              <div className="absolute top-4 left-4 flex items-center gap-2 bg-black/50 backdrop-blur-sm px-3 py-2 rounded-lg">
                <Sparkles className="size-4 text-yellow-400" />
                <span className="text-white text-sm">AI-Enhanced Replay</span>
              </div>

              {/* Recording Date */}
              <div className="absolute top-4 right-4 bg-black/50 backdrop-blur-sm px-3 py-2 rounded-lg">
                <span className="text-white text-sm">Recorded {webinar.date.toLocaleDateString()}</span>
              </div>
            </div>
          </Card>

          {/* Video Controls */}
          <Card>
            <CardContent className="p-4">
              {/* Progress Bar */}
              <div className="mb-4">
                <Slider
                  value={[progress]}
                  onValueChange={(value) => setProgress(value[0])}
                  max={100}
                  step={1}
                  className="mb-2"
                />
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{Math.floor(progress / 100 * 60)}:00</span>
                  <span>60:00</span>
                </div>
              </div>

              {/* Control Buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setProgress(Math.max(0, progress - 10))}
                  >
                    <SkipBack className="size-5" />
                  </Button>
                  <Button 
                    size="icon"
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="size-10"
                  >
                    {isPlaying ? <Pause className="size-5" /> : <Play className="size-5" />}
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setProgress(Math.min(100, progress + 10))}
                  >
                    <SkipForward className="size-5" />
                  </Button>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2">
                    <Volume2 className="size-4 text-muted-foreground" />
                    <Slider
                      value={[volume]}
                      onValueChange={(value) => setVolume(value[0])}
                      max={100}
                      step={1}
                      className="w-24"
                    />
                  </div>
                  <Button variant="ghost" size="icon">
                    <Maximize className="size-5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar - AI Insights */}
        <div className="w-96 border-l border-border">
          <Tabs defaultValue="summary" className="h-full flex flex-col">
            <div className="border-b border-border px-4 pt-4">
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="summary">Summary</TabsTrigger>
                <TabsTrigger value="highlights">Highlights</TabsTrigger>
                <TabsTrigger value="resources">Resources</TabsTrigger>
              </TabsList>
            </div>

            <ScrollArea className="flex-1">
              <TabsContent value="summary" className="m-0 p-6 space-y-6">
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <Sparkles className="size-5 text-yellow-500" />
                    <h3>AI-Generated Summary</h3>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="mb-2 flex items-center gap-2">
                        Key Takeaways
                      </h4>
                      <ul className="space-y-2">
                        {aiSummary.keyPoints.map((point, index) => (
                          <li key={index} className="text-sm text-muted-foreground flex gap-2">
                            <span className="text-yellow-500 shrink-0">•</span>
                            <span>{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Separator />

                    <div>
                      <h4 className="mb-2 flex items-center gap-2">
                        Action Items
                      </h4>
                      <ul className="space-y-2">
                        {aiSummary.actionItems.map((item, index) => (
                          <li key={index} className="text-sm text-muted-foreground flex gap-2">
                            <span className="text-green-500 shrink-0">✓</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                <Card className="bg-accent">
                  <CardContent className="p-4">
                    <p className="text-xs text-muted-foreground">
                      This summary was personalized for your role as a <span className="text-foreground">Marketing Manager</span> by Helios AI.
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="highlights" className="m-0 p-6 space-y-4">
                <div>
                  <h3 className="mb-4">Chat Highlights</h3>
                  <div className="space-y-3">
                    {chatHighlights.map((highlight, index) => (
                      <Card key={index} className="cursor-pointer hover:bg-accent transition-colors"
                            onClick={() => setProgress((parseInt(highlight.time.split(':')[0]) / 60) * 100)}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <span className="text-xs text-yellow-500">{highlight.time}</span>
                            <Badge 
                              variant="outline" 
                              className={
                                highlight.sentiment === 'positive' 
                                  ? 'text-green-600 border-green-600'
                                  : 'text-blue-600 border-blue-600'
                              }
                            >
                              {highlight.sentiment}
                            </Badge>
                          </div>
                          <p className="text-sm mb-1">{highlight.message}</p>
                          <p className="text-xs text-muted-foreground">{highlight.user}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="resources" className="m-0 p-6 space-y-4">
                <div>
                  <h3 className="mb-4">Resources & Downloads</h3>
                  <div className="space-y-2">
                    {aiSummary.resources.map((resource, index) => (
                      <Card key={index} className="cursor-pointer hover:bg-accent transition-colors">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm mb-1">{resource.name}</p>
                              <p className="text-xs text-muted-foreground">Click to download</p>
                            </div>
                            <Download className="size-4 text-muted-foreground" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="mb-3">Related Webinars</h4>
                  <Card>
                    <CardContent className="p-4">
                      <p className="text-sm mb-1">Advanced SEO Strategies</p>
                      <p className="text-xs text-muted-foreground mb-2">Coming Oct 15, 2025</p>
                      <Button size="sm" variant="outline" className="w-full">
                        Register Now
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </ScrollArea>
          </Tabs>
        </div>
      </div>
    </div>
  );
}