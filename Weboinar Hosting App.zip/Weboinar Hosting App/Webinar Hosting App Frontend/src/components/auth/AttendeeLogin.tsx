import { useState } from 'react';
import { ArrowLeft, Sparkles, Mail, Lock, User, Briefcase, Building2 } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { Separator } from '../ui/separator';
import { toast } from 'sonner@2.0.3';
import type { User as UserType } from '../../App';

interface AttendeeLoginProps {
  onLogin: (user: UserType) => void;
  onBack: () => void;
}

export function AttendeeLogin({ onLogin, onBack }: AttendeeLoginProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: '',
    company: '',
    interests: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isSignUp) {
      // Sign up flow
      if (!formData.name || !formData.email || !formData.password || !formData.role) {
        toast.error('Please fill in all required fields');
        return;
      }
      
      toast.success('Account created successfully! Welcome to Helios.');
      onLogin({
        name: formData.name,
        email: formData.email,
        type: 'attendee',
        role: formData.role,
        company: formData.company,
      });
    } else {
      // Login flow
      if (!formData.email || !formData.password) {
        toast.error('Please enter your email and password');
        return;
      }
      
      toast.success('Welcome back to Helios!');
      // Using demo data for login
      onLogin({
        name: 'Priya Sharma',
        email: formData.email,
        type: 'attendee',
        role: 'Marketing Manager',
        company: 'Tech Solutions Inc.',
      });
    }
  };

  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-blue-950/20 dark:via-indigo-950/20 dark:to-purple-900/20">
      <div className="w-full max-w-md px-6">
        <Button variant="ghost" onClick={onBack} className="mb-6 gap-2">
          <ArrowLeft className="size-4" />
          Back
        </Button>

        <Card className="shadow-2xl">
          <CardHeader className="text-center pb-6">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="size-12 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
                <Sparkles className="size-7 text-white" />
              </div>
            </div>
            <CardTitle className="text-2xl">
              {isSignUp ? 'Create Attendee Account' : 'Attendee Login'}
            </CardTitle>
            <CardDescription>
              {isSignUp 
                ? 'Join Helios to discover personalized webinar experiences' 
                : 'Welcome back! Sign in to continue your learning journey'}
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignUp && (
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                      id="name"
                      type="text"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="pl-10"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>

              {isSignUp && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="role">Job Title / Role *</Label>
                    <div className="relative">
                      <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        id="role"
                        type="text"
                        placeholder="e.g., Marketing Manager, Software Engineer"
                        value={formData.role}
                        onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="company">Company (Optional)</Label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                      <Input
                        id="company"
                        type="text"
                        placeholder="Your company name"
                        value={formData.company}
                        onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="interests">Interests (Optional)</Label>
                    <Input
                      id="interests"
                      type="text"
                      placeholder="e.g., Marketing, SEO, Data Science"
                      value={formData.interests}
                      onChange={(e) => setFormData({ ...formData, interests: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">
                      Helios will use this to personalize your recommendations
                    </p>
                  </div>
                </>
              )}

              <Button type="submit" className="w-full" size="lg">
                {isSignUp ? 'Create Account' : 'Sign In'}
              </Button>

              <Separator />

              <div className="text-center text-sm">
                <span className="text-muted-foreground">
                  {isSignUp ? 'Already have an account?' : "Don't have an account?"}
                </span>
                {' '}
                <button
                  type="button"
                  onClick={() => setIsSignUp(!isSignUp)}
                  className="text-primary hover:underline"
                >
                  {isSignUp ? 'Sign In' : 'Sign Up'}
                </button>
              </div>
            </form>

            {isSignUp && (
              <div className="mt-6 p-4 bg-accent rounded-lg">
                <div className="flex items-start gap-2">
                  <Sparkles className="size-4 text-yellow-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    By signing up, Helios AI will start building your personalized interest profile to recommend the most relevant webinars for you.
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <p className="text-center text-xs text-muted-foreground mt-6">
          By continuing, you agree to Helios Terms of Service and Privacy Policy
        </p>
      </div>
    </div>
  );
}