import { Users, Presentation, Sparkles, ArrowRight } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import type { AuthView } from '../../App';

interface LoginSelectionProps {
  onSelectType: (type: AuthView) => void;
}

export function LoginSelection({ onSelectType }: LoginSelectionProps) {
  return (
    <div className="size-full flex items-center justify-center bg-gradient-to-br from-orange-50 via-yellow-50 to-orange-100 dark:from-orange-950/20 dark:via-yellow-950/20 dark:to-orange-900/20">
      <div className="w-full max-w-5xl px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="size-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center shadow-2xl">
              <Sparkles className="size-9 text-white" />
            </div>
          </div>
          <h1 className="mb-3">Welcome to Helios</h1>
          <p className="text-muted-foreground text-lg">
            The AI-powered webinar intelligence platform
          </p>
        </div>

        {/* Selection Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Attendee Card */}
          <Card className="hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 hover:border-yellow-300 dark:hover:border-yellow-700" 
                onClick={() => onSelectType('attendee-login')}>
            <CardContent className="p-8">
              <div className="size-16 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center mb-6">
                <Users className="size-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h2 className="mb-3">Join as Attendee</h2>
              <p className="text-muted-foreground mb-6">
                Discover and attend webinars tailored to your interests with AI-powered recommendations and personalized experiences.
              </p>
              <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                <li className="flex items-center gap-2">
                  <div className="size-1.5 bg-blue-500 rounded-full" />
                  Personalized webinar recommendations
                </li>
                <li className="flex items-center gap-2">
                  <div className="size-1.5 bg-blue-500 rounded-full" />
                  AI-generated summaries tailored to your role
                </li>
                <li className="flex items-center gap-2">
                  <div className="size-1.5 bg-blue-500 rounded-full" />
                  Real-time transcription and Q&A assistance
                </li>
                <li className="flex items-center gap-2">
                  <div className="size-1.5 bg-blue-500 rounded-full" />
                  Track your engagement and learning progress
                </li>
              </ul>
              <Button className="w-full gap-2" size="lg">
                Continue as Attendee
                <ArrowRight className="size-4" />
              </Button>
            </CardContent>
          </Card>

          {/* Host Card */}
          <Card className="hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 hover:border-orange-300 dark:hover:border-orange-700"
                onClick={() => onSelectType('host-login')}>
            <CardContent className="p-8">
              <div className="size-16 bg-gradient-to-br from-yellow-100 to-orange-100 dark:from-yellow-900/30 dark:to-orange-900/30 rounded-xl flex items-center justify-center mb-6">
                <Presentation className="size-8 text-orange-600 dark:text-orange-400" />
              </div>
              <h2 className="mb-3">Host a Webinar</h2>
              <p className="text-muted-foreground mb-6">
                Create and manage engaging webinars with Helios AI automating engagement, moderation, and follow-ups.
              </p>
              <ul className="space-y-2 text-sm text-muted-foreground mb-6">
                <li className="flex items-center gap-2">
                  <div className="size-1.5 bg-orange-500 rounded-full" />
                  AI-powered chat moderation and Q&A prioritization
                </li>
                <li className="flex items-center gap-2">
                  <div className="size-1.5 bg-orange-500 rounded-full" />
                  Real-time engagement analytics and insights
                </li>
                <li className="flex items-center gap-2">
                  <div className="size-1.5 bg-orange-500 rounded-full" />
                  Automated personalized follow-ups
                </li>
                <li className="flex items-center gap-2">
                  <div className="size-1.5 bg-orange-500 rounded-full" />
                  Attendee profiling and targeting
                </li>
              </ul>
              <Button className="w-full gap-2 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600" size="lg">
                Continue as Host
                <ArrowRight className="size-4" />
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <div className="text-center text-sm text-muted-foreground">
          <p>Powered by Helios AI • Maximizing engagement through hyper-personalization</p>
        </div>
      </div>
    </div>
  );
}